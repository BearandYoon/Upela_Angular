<?php

# phing;upela;Atlas;2014-11-17 17:58:24;v1.6;bb2b1b91260ab31baf81a0a7322b3a55f64f55fe;1.1.1

/**
 * Upela connector - shipping module
 * More info on www.upela.com
 * @copyright Studio Kiwik <http://www.studio-kiwik.fr>
 * @author Tomasz Slominski <tomasz@studio-kiwik.fr>
 * @version 1.1.1
 */
class upela extends CarrierModule {

# CLASS CONSTANTS

	# COLOPHON

	const VERSION						= '1.1.1';
	const NAME							= 'upela';
	const AUTHOR						= 'Studio Kiwik';

	# CONFIG OPTIONS

	const OPT_API_MODE					= 'UPELA_API_MODE';
	const OPT_API_METHOD 				= 'UPELA_API_METHOD';

	const OPT_API_LOGIN 				= 'UPELA_API_LOGIN';
	const OPT_API_PASSWORD 				= 'UPELA_API_PASSWORD';

	const OPT_AVERAGE_PACKAGES_NUMBER 	= 'UPELA_AVERAGE_PACKAGES_NUMBER';
	const OPT_AVERAGE_PACKAGE_WEIGHT 	= 'UPELA_AVERAGE_PACKAGE_WEIGHT';
	const OPT_AVERAGE_DIMENSION_X 		= 'UPELA_AVERAGE_DIMENSION_X';
	const OPT_AVERAGE_DIMENSION_Y 		= 'UPELA_AVERAGE_DIMENSION_Y';
	const OPT_AVERAGE_DIMENSION_Z		= 'UPELA_AVERAGE_DIMENSION_Z';

	const OPT_SHIP_COUNTRY 				= 'UPELA_SHIP_COUNTRY';
	const OPT_SHIP_POSTAL_CODE 			= 'UPELA_SHIP_POSTAL_CODE';
	const OPT_SHIP_CITY 				= 'UPELA_SHIP_CITY';
	const OPT_SHIP_IS_PROFFESIONAL 		= 'UPELA_SHIP_IS_PROFFESIONAL';
	const OPT_SHIP_ADDRESS1 			= 'UPELA_SHIP_ADDRESS1';
	const OPT_SHIP_ADDRESS2 			= 'UPELA_SHIP_ADDRESS2';
	const OPT_SHIP_ADDRESS3				= 'UPELA_SHIP_ADDRESS3';
	const OPT_SHIP_NAME 				= 'UPELA_SHIP_NAME';
	const OPT_SHIP_COMPANY				= 'UPELA_SHIP_COMPANY';
	const OPT_SHIP_PHONE 				= 'UPELA_SHIP_PHONE';
	const OPT_SHIP_EMAIL 				= 'UPELA_SHIP_EMAIL';

	const OPT_PICKUP_READY_TIME			= 'UPELA_PICKUP_READY_TIME';
	const OPT_PICKUP_CLOSE_TIME			= 'UPELA_PICKUP_CLOSE_TIME';

	const OPT_SELECTION					= 'UPELA_SELECTION';

	const OPT_CHEAPEST_CARRIER_ID		= 'UPELA_CHEAPEST_CARRIER_ID';
	const OPT_FASTEST_CARRIER_ID		= 'UPELA_FASTEST_CARRIER_ID';

	const OPT_OFFERT_LIFETIME			= 'UPELA_OFFERT_LIFETIME';
	const OPT_EXTRA_MARGE				= 'UPELA_EXTRA_MARGE';
	const OPT_DELIVERY_DELAY			= 'UPELA_DELIVERY_DELAY';
	
	const OPT_WS_TIMEOUT				= 'UPELA_WS_TIMEOUT';
	const OPT_CONTENT					= 'UPELA_CONTENT';
	
	# OPTIONS VALUES

	const VALUE_CHEAPEST				= 'cheapest';
	const VALUE_FASTEST					= 'fastest';
	const VALUE_CHOOSE					= 'cheapest_and_fastest';
	const VALUE_API_URL_TEST			= 'https://dev.upela.com/';
	const VALUE_API_URL_PRODUCTION		= 'https://www.upela.com/';
	const VALUE_API_PATH				= 'api/';

	const VALUE_MODE_PRODUCTION			= 'production';
	const VALUE_MODE_TEST				= 'test';
	const VALUE_METHOD_POST				= 'post';
	const VALUE_METHOD_GET				= 'get';
	
	const VALUE_WEEK					= 7;
	const VALUE_MONTH					= 30;
	const VALUE_EVER					= null;

	# MESSAGES

	const MSG_CARRIER_NAME_CHEAPEST			= 'MSG_CARRIER_NAME_CHEAPEST';
	const MSG_CARRIER_NAME_FASTEST			= 'MSG_CARRIER_NAME_FASTEST';

	const MSG_DESCRIPTION					= 'MSG_DESCRIPTION';
	const MSG_DISPLAY_NAME					= 'MSG_DISPLAY_NAME';
	const MSG_DELAY							= 'MSG_DELAY';
	const MSG_FASTEST						= 'MSG_FASTEST';
	const MSG_CHEAPEST						= 'MSG_CHEAPEST';
	
	const MSG_CHOOSE						= 'MSG_CHOOSE';
	const MSG_MODE_TEST						= 'MSG_MODE_TEST';
	const MSG_MODE_PRODUCTION				= 'MSG_MODE_PRODUCTION';

	const MSG_SHIP_DEMAND_SUCCESS			= 'MSG_SHIP_DEMAND_SUCCESS';
	const MSG_SHIP_DEMAND_FAIL				= 'MSG_SHIP_DEMAND_FAIL';

	const MSG_REASON						= 'MSG_REASON';
	const MSG_CONTENT						= 'MSG_CONTENT';
	
	const MSG_WEEK							= 'MSG_WEEK';
	const MSG_MONTH							= 'MSG_MONTH';
	const MSG_EVER							= 'MSG_EVER';
	
	const MSG_INVALID_VALUE					= 'MSG_INVALID_VALUE';
	const MSG_RATE_DEMAND_FAILED			= 'MSG_RATE_DEMAND_FAILED';
	
	const MSG_ERROR_LOGIN					= 'MSG_ERROR_LOGIN';
	const MSG_ERROR_PASSWORD				= 'MSG_ERROR_PASSWORD';
	
	const MSG_TRACKING_NUMBER_UPDATED 		= 'MSG_TRACKING_NUMBER_UPDATED';
	const MSG_TRACKING_NUMBER_UPDATE_ERROR	= 'MSG_TRACKING_NUMBER_UPDATE_ERROR';
	
# CLASS VARS

	/**
	 * Runtime configuration
	 * @var array
	 */
	protected $aConfig = array();

	/**
	 * Default configuration
	 * @var array
	 */
	protected $aDefaultConfig = array(
		self::OPT_API_MODE 					=> self::VALUE_MODE_TEST,
		self::OPT_API_METHOD 				=> self::VALUE_METHOD_POST,

		self::OPT_API_LOGIN 				=> '', 
		self::OPT_API_PASSWORD 				=> '',

		self::OPT_AVERAGE_PACKAGES_NUMBER 	=> 1,
		self::OPT_AVERAGE_PACKAGE_WEIGHT 	=> 1,
		self::OPT_AVERAGE_DIMENSION_X 		=> 1,
		self::OPT_AVERAGE_DIMENSION_Y 		=> 1,
		self::OPT_AVERAGE_DIMENSION_Z		=> 1,

		self::OPT_SHIP_COUNTRY 				=> '',
		self::OPT_SHIP_POSTAL_CODE 			=> '',
		self::OPT_SHIP_CITY 				=> '',
		self::OPT_SHIP_IS_PROFFESIONAL 		=> '',
		self::OPT_SHIP_ADDRESS1 			=> '',
		self::OPT_SHIP_ADDRESS2 			=> '',
		self::OPT_SHIP_ADDRESS3				=> '',
		self::OPT_SHIP_NAME 				=> '',
		self::OPT_SHIP_COMPANY				=> '',
		self::OPT_SHIP_PHONE 				=> '',
		self::OPT_SHIP_EMAIL 				=> '',

		self::OPT_PICKUP_READY_TIME			=> '1400',
		self::OPT_PICKUP_CLOSE_TIME			=> '1800',

		self::OPT_SELECTION					=> self::VALUE_CHOOSE,


		self::OPT_CHEAPEST_CARRIER_ID		=> 0,
		self::OPT_FASTEST_CARRIER_ID		=> 0,
		self::OPT_OFFERT_LIFETIME			=> 1800,
		self::OPT_EXTRA_MARGE				=> 0,
		self::OPT_DELIVERY_DELAY			=> 1,
		self::OPT_WS_TIMEOUT				=> 30,
		self::OPT_CONTENT					=> '',
	
	);

	/**
	 * Default configuration
	 * @var array
	 */
	protected $aConfigValidation = array(
			self::OPT_API_MODE 					=> array(array(array('upela', 'isNotEmpty'))),
			self::OPT_API_METHOD 				=> array(array(array('upela', 'isNotEmpty'))),
			self::OPT_API_LOGIN 				=> array(array(array('upela', 'isNotEmpty'), self::MSG_ERROR_LOGIN)),
			self::OPT_API_PASSWORD 				=> array(array(array('upela', 'isNotEmpty'), self::MSG_ERROR_PASSWORD)),
			self::OPT_AVERAGE_PACKAGES_NUMBER 	=> array(array(array('upela', 'isNotEmpty')),array(array('Validate', 'isUnsignedInt'))),
			self::OPT_AVERAGE_PACKAGE_WEIGHT 	=> array(array(array('upela', 'isNotEmpty')),array(array('Validate', 'isFloat'))),
			self::OPT_AVERAGE_DIMENSION_X 		=> array(array(array('upela', 'isNotEmpty')),array(array('Validate', 'isUnsignedInt'))),
			self::OPT_AVERAGE_DIMENSION_Y 		=> array(array(array('upela', 'isNotEmpty')),array(array('Validate', 'isUnsignedInt'))),
			self::OPT_AVERAGE_DIMENSION_Z		=> array(array(array('upela', 'isNotEmpty')),array(array('Validate', 'isUnsignedInt'))),
			self::OPT_SHIP_COUNTRY 				=> array(array(array('upela', 'isNotEmpty')),array(array('Validate', 'isStateIsoCode'))),
			self::OPT_SHIP_POSTAL_CODE 			=> array(array(array('upela', 'isNotEmpty')),array(array('Validate', 'isPostCode'))),
			self::OPT_SHIP_CITY 				=> array(array(array('upela', 'isNotEmpty')), array(array('Validate', 'isCityName'))),
			self::OPT_SHIP_IS_PROFFESIONAL 		=> array(array(array('Validate', 'isUnsignedInt'))),
			self::OPT_SHIP_ADDRESS1 			=> array(array(array('upela', 'isNotEmpty')), array(array('Validate', 'isCityName'))),
			self::OPT_SHIP_ADDRESS2 			=> array(),
			self::OPT_SHIP_ADDRESS3				=> array(),
			self::OPT_SHIP_NAME 				=> array(array(array('upela', 'isNotEmpty'))),
			self::OPT_SHIP_COMPANY				=> array(array(array('upela', 'isNotEmpty')), ),
			self::OPT_SHIP_PHONE 				=> array(array(array('upela', 'isNotEmpty')), array(array('Validate', 'isPhoneNumber'))),
			self::OPT_SHIP_EMAIL 				=> array(array(array('upela', 'isNotEmpty')), array(array('Validate', 'isEmail'))),
			self::OPT_PICKUP_READY_TIME			=> array(array(array('upela', 'isNotEmpty')), array(array('upela', 'isPickupDate'))),
			self::OPT_PICKUP_CLOSE_TIME			=> array(array(array('upela', 'isNotEmpty')), array(array('upela', 'isPickupDate'))),
			self::OPT_SELECTION					=> array(array(array('Validate', 'isString'))),
			self::OPT_CHEAPEST_CARRIER_ID		=> array(array(array('upela', 'isNotEmpty')), array(array('Validate', 'isUnsignedId'))),
			self::OPT_FASTEST_CARRIER_ID		=> array(array(array('upela', 'isNotEmpty')), array(array('Validate', 'isUnsignedId'))),
			self::OPT_OFFERT_LIFETIME			=> array(array(array('upela', 'isNotEmpty')), array(array('Validate', 'isUnsignedInt'))),
			self::OPT_EXTRA_MARGE				=> array(array(array('Validate', 'isPercentage'))),
			self::OPT_DELIVERY_DELAY			=> array(array(array('upela', 'isNotEmpty')), array(array('Validate', 'isUnsignedInt'))),
			self::OPT_WS_TIMEOUT				=> array(array(array('Validate', 'isUnsignedInt'))),
			self::OPT_CONTENT					=> array(array(array('upela', 'isNotEmpty'))),			
	);
	
	/**
	 * Definition of default upela carrier
	 * @var array
	 */
	protected $aCarrierDefinitions = array(

		self::VALUE_CHEAPEST => array(
			'name' 					=> self::MSG_CARRIER_NAME_CHEAPEST,
			'url' 					=> 'fr/suivi?code=@',
			'delay' 				=> self::MSG_DELAY,
			'active' 				=> 1,
			'deleted' 				=> 0,
			'shipping_handling' 	=> 1,
			'range_behavior' 		=> 0,
			'is_module' 			=> 0,
			'is_free' 				=> 0,
			'shipping_method' 		=> Carrier::SHIPPING_METHOD_WEIGHT,
			'shipping_external'		=> 1,
			'external_module_name'	=> self::NAME,
			'need_range' 			=> 0,
			'max_width'				=> 0,
			'max_height'			=> 0,
			'max_depth'				=> 0,
			'max_weighth'			=> 0,
			'grade'					=> 8
		),

	self::VALUE_FASTEST => array(
			'name' 					=> self::MSG_CARRIER_NAME_FASTEST,
			'url' 					=> 'fr/suivi?code=@',
			'delay' 				=> self::MSG_DELAY,
			'active' 				=> 1,
			'deleted' 				=> 0,
			'shipping_handling' 	=> 1,
			'range_behavior' 		=> 0,
			'is_module' 			=> 0,
			'is_free' 				=> 0,
			'shipping_method' 		=> Carrier::SHIPPING_METHOD_WEIGHT,
			'shipping_external'		=> 1,
			'external_module_name'	=> self::NAME,
			'need_range' 			=> 0,
			'max_width'				=> 0,
			'max_height'			=> 0,
			'max_depth'				=> 0,
			'max_weighth'			=> 0,
			'grade'					=> 9
		));

	/**
	 *
	 * @var UpelaApi
	 */
	protected $oApi = null;

	/**
	 * Validation errors
	 * @var array
	 */
	protected $aErrors = array();
	
	/**
	 * Id carrier set by Cart during calculation of the shipping cost
	 * @var integer
	 */
	public $id_carrier = -1;

	/**
	 * Rate cache
	 * @var array
	 */
	protected static $aRateCache 		= array();

	/**
	 * Cache for mapping id_carrier -> id_offert (to avoid display the same offert twice)
	 * @var array
	 */
	protected static $aCarrierOffert	= array();

# CLASS METHODS

	/**
	 * Class constructor
	 */
	public function __construct($name = null, Context $context = null){

		$this->name 	= self::NAME;

		$this->version 	= self::VERSION;

		$this->tab 		= 'shipping_logistics';

		$this->author 	= self::AUTHOR;
		
		$this->bootstrap = $this->isPrestashop16x();

		parent::__construct($name, $context);

    if (class_exists('Context')) {
      $this->context = Context::getContext();
    } else {
      global $smarty, $cookie;
      $this->context = new StdClass();
      $this->context->smarty = $smarty;
      $this->context->cookie = $cookie;
			$this->context->language = new Language(defined('_PS_LANG_DEFAULT_') ? constant('_PS_LANG_DEFAULT_') : Configuration::get('PS_LANG_DEFAULT'));
    }
    if (is_object($this->context->smarty)) {
      $this->smarty = $this->context->smarty->createData($this->context->smarty);
    }
		
		if ($this->isPrestashop14x()){
			
			global $smarty;
			
			$this->context = new stdClass();
			
			$this->context->smarty = $smarty;
			
			$this->context->language = new Language(defined('_PS_LANG_DEFAULT_') ? constant('_PS_LANG_DEFAULT_') : Configuration::get('PS_LANG_DEFAULT'));
			
		}
		
		if (!$this->isPrestashop14x()){
			
			$this->displayName = $this->l(self::MSG_DISPLAY_NAME);
			
			$this->description = $this->l(self::MSG_DESCRIPTION);
			
		} else {
			
			$this->displayName = $this->l('Upela');
			
			$this->description = $this->l('Upela');
				
		}

		$this->loadOptions();

	} // __construct

	# INSTALL / UNNISTALL

	/**
	 * Installs module
	 * @return boolean True on success
	 */
	public function install(){

		if (!parent::install()){

			return false;

		}
		
		foreach (array('updateCarrier', $this->isPrestashop14x() ? 'newOrder' : 'actionValidateOrder', 'extraCarrier', 'adminOrder') as $sHookName){

			$this->registerHook($sHookName);

		} // foreach
		
		if ($this->isPrestashop16x()){
			$this->registerHook('displayAdminOrderTabShip');
		}

		$this->aConfig = $this->aDefaultConfig;

		$this->setOption(self::OPT_SHIP_NAME, Configuration::get('PS_SHOP_NAME'));
		$this->setOption(self::OPT_SHIP_COMPANY, Configuration::get('PS_SHOP_NAME'));
		$this->setOption(self::OPT_SHIP_EMAIL, Configuration::get('PS_SHOP_EMAIL'));
		$this->setOption(self::OPT_SHIP_ADDRESS1, Configuration::get('PS_SHOP_ADDR1'));
		$this->setOption(self::OPT_SHIP_ADDRESS2, Configuration::get('PS_SHOP_ADDR2'));
		$this->setOption(self::OPT_SHIP_POSTAL_CODE, Configuration::get('PS_SHOP_CODE'));
		$this->setOption(self::OPT_SHIP_CITY, Configuration::get('PS_SHOP_CITY'));
		$this->setOption(self::OPT_SHIP_PHONE, Configuration::get('PS_SHOP_PHONE'));
		$this->setOption(self::OPT_SHIP_IS_PROFFESIONAL, Configuration::get('PS_SHOP_DETAILS') ? 1 : 0);
		$this->setOption(self::OPT_SHIP_COUNTRY, Country::getIsoById((int)Configuration::get('PS_SHOP_COUNTRY_ID')));
		$this->setOption(self::OPT_CONTENT, $this->l(self::MSG_CONTENT));
		
		// must be before save options
		$this->createCarriers();

		$this->saveOptions();

		$this->executeSqlFile(_PS_MODULE_DIR_ . $this->name . DIRECTORY_SEPARATOR . 'install' . DIRECTORY_SEPARATOR . 'create.sql');

		foreach (array('UpelaOffert', 'UpelaPickupDemand') as $sClassName) {
			
			$sSource = _PS_MODULE_DIR_ . $this->name . DIRECTORY_SEPARATOR . 'inc' . ($this->isPrestashop14x() ? DIRECTORY_SEPARATOR . '1.4.x' . DIRECTORY_SEPARATOR :  DIRECTORY_SEPARATOR) . $sClassName . '.php';
			$sTarget = _PS_CLASS_DIR_ . DIRECTORY_SEPARATOR . $sClassName . '.php';
			if (file_exists($sTarget)){
				unlink($sTarget);
			}
			copy($sSource, $sTarget);
			
		}
		
		if (!$this->isPrestashop14x()){
		
			Autoload::getInstance()->generateIndex();
			
		}
				

		return true;

	} // install

	/**
	 * Uninstalls module
	 * @todo Delete own carriers (if no orders)
	 * @todo Delete configuration
	 * @retun boolean True on success
	 */
	public function uninstall(){

		foreach (array(self::OPT_CHEAPEST_CARRIER_ID, self::OPT_FASTEST_CARRIER_ID) as $sOptionName) {

			$nCarrierId = (int)$this->getOption($sOptionName);

			if ($nCarrierId){

				$oCarrier = new Carrier($nCarrierId);

				$this->setGroups($oCarrier, array(), true);

				$oCarrier->active = 0;

				$oCarrier->deleted = 1;

				$oCarrier->update();

			} // if

		} // foreach

		foreach (array_keys($this->aDefaultConfig) as $sOptionName){

			Configuration::deleteByName($sOptionName);

		}

		foreach (array('updateCarrier', 'updateOrderStatus', $this->isPrestashop14x() ? 'newOrder' : 'actionValidateOrder', 'extraCarrier') as $sHookName){

			$this->unregisterHook($sHookName);

		} // foreach

		return parent::uninstall();

	} // uninstall

	/**
	 * Create predefined carriers
	 */
	protected function createCarriers(){

		$this->setOption(self::OPT_CHEAPEST_CARRIER_ID, $this->createCarrier($this->aCarrierDefinitions[self::VALUE_CHEAPEST]));

		$this->setOption(self::OPT_FASTEST_CARRIER_ID, $this->createCarrier($this->aCarrierDefinitions[self::VALUE_FASTEST]));

	}

	/**
	 * Adds new carrier linked to the module
	 * @todo Add logo
	 * @todo delete / desactivate other carriers
	 * @param array $aDefinition Carrier definition, see upela::$aCarrierDefinitions
	 */
	protected function createCarrier($aDefinition){

		$oCarrier = new Carrier();

		$this->setCarrierProperties($oCarrier, $aDefinition);

		if ($oCarrier->add()){

			$this->addCarrierToGroups($oCarrier);

			$this->addCarrierToZones($oCarrier);

			$oRangeWeight = $this->addCarrierRangeWeight($oCarrier);
			
			$this->addDeliveryPrice($oCarrier, $oRangeWeight);
						
			$this->copyCarrierImage($oCarrier);

			return $oCarrier->id;

		} // if

		return 0;

	} // createCarrier

	protected function addDeliveryPrice($oCarrier, $oRangeWeight) {
		
		foreach ($oCarrier->getZones() as $aZone){

			Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'delivery` (`id_carrier`, `id_range_price`, `id_range_weight`, `id_zone`, `price`) 
				VALUES ('.(int)($oCarrier->id).', NULL, ' .(int)($oRangeWeight->id).', '.(int)($aZone['id_zone']). ', 0)');

		} // foreach
		
	} 
	
	/**
	 * Adds empty weight range to carrier (without it carrier is not visible, even if it doesn't use one)
	 * @param Carrier $oCarrier
	 */
	protected function addCarrierRangeWeight(Carrier $oCarrier){

		$oRangeWeight = new RangeWeight();

		$oRangeWeight->id_carrier = $oCarrier->id;

		$oRangeWeight->delimiter1 = 0;

		$oRangeWeight->delimiter2 = 99999;

		$oRangeWeight->add();
		
		return $oRangeWeight;

	} // addCarrierRangeWeight

	/**
	 * Sets carrier properties. Generates multilang / translated properties if necessary
	 * @param Carrier $oCarrier
	 * @param array $aDefinition <string : property name => mixed : property value>
	 */
	protected function setCarrierProperties($oCarrier, $aDefinition){

		foreach ($aDefinition as $sKey=>$mValue){

			if ($sKey === 'url'){

				$mValue = $this->getBaseUrl() . $mValue;

			} // if

			if ($sKey === 'delay'){

				$mValue = array_fill_keys($this->getLanguagesIds(), $this->l($mValue));

			} // if

			if ($sKey === 'name'){

				$mValue =  $this->l($mValue);

			} // if

			$oCarrier->{$sKey} = $mValue;

		} // foreach

	} // setCarrierProperties

	/**
	 * Copies default image as carrier logo
	 * @param Carrier $oCarrier
	 * @return boolean
	 */
	protected function copyCarrierImage($oCarrier){

		$sSource 		= _PS_MODULE_DIR_ . $this->name . DIRECTORY_SEPARATOR . 'img' . DIRECTORY_SEPARATOR . 'carrier-logo.jpg';

		$sDestination 	= _PS_SHIP_IMG_DIR_ . $oCarrier->id . '.jpg';

		return copy($sSource, $sDestination);

	} // copyCarrierImage

	/**
	 * Adds carrier to all groups
	 * @param Carrier $oCarrier
	 */
	protected function addCarrierToGroups($oCarrier){

		$aGroups = array();

		foreach (Group::getGroups($this->context->language->id) as $aGroup){

			$aGroups[] = (int)$aGroup['id_group'];

		} // foreach

		$this->setGroups($oCarrier, $aGroups);

	} // addCarrierToGroups

	/**
	 * Adds carrier to all active zones
	 * @param Carrier $oCarrier
	 */
	protected function addCarrierToZones(Carrier $oCarrier){

		foreach (Zone::getZones(true) as $aZone){

			$oCarrier->addZone((int)$aZone['id_zone']);

		} // foreach

	} // addCarrierToZones

	/**
	 * Reads and executes contents of sql file
	 * @param string $sFilePath Path to sql file, with queries separated by ';'
	 * @return boolean True if all queries executed succesfully, false otherwise
	 * @todo Review regexp pattern
	 */
	protected function executeSqlFile($sFilePath){

		$sSqlString = (file_exists($sFilePath) && is_readable($sFilePath) ? (string)file_get_contents($sFilePath) : '');

		$sSqlString = str_replace('%%PREFIX%%', _DB_PREFIX_, $sSqlString);

		$aQueries = preg_split('#;\s*[\r\n]+#', $sSqlString);

		foreach (array_filter(array_map('trim', $aQueries)) as $sQuery){

			$mResult = Db::getInstance()->execute($sQuery);

			if ($mResult === false){

				Logger::addLog('Query FAILED ' . $sQuery);

				return false;

			} // if

		} // foreach

		return true;

	} // executeSqlFile

	# OPTIONS HANDLING

	/**
	 * Loads all options presents in default config
	 * @tod add meaningful return
	 */
	protected function loadOptions(){

		foreach (array_keys($this->aDefaultConfig) as $sOptionName) {

			$this->loadOption($sOptionName);

		} // foreach

	} // loadOptions

	/**
	 * Saves all options presents in default config
	 * @tod add meaningful return
	 */
	protected function saveOptions(){

		foreach (array_keys($this->aDefaultConfig) as $sOptionName) {

			$this->saveOption($sOptionName);

		} // foreach

	} // saveOptions

	/**
	 * Gets given option value
	 * @param string $sOptionName Option name
	 * @return mixed Option value or null if option does not exists
	 */
	protected function getOption($sOptionName){

		return isset($this->aConfig[$sOptionName]) ? $this->aConfig[$sOptionName] : null;

	} // getOption

	/**
	 * Get all options
	 * @return array <string : option name => mixed : option value>
	 */
	protected function getOptions(){

		return $this->aConfig;

	} // getOptions

	/**
	 * Sets option. For saving option see upela::saveOption
	 * @param string $sOptionName Name of option
	 * @param mixed $mValue Value of option
	 * @return upela Self
	 */
	protected function setOption($sOptionName, $mValue){

		$this->aConfig[(string)$sOptionName] = $mValue;

		return $this;

	} // setOption

	/**
	 * Saves option to configuration
	 * @param string $sOptionName Name of option
	 * @return upela Self
	 */
	protected function saveOption($sOptionName){

		Configuration::updateValue($sOptionName, $this->getOption($sOptionName));

		return $this;

	} // saveOption

	/**
	 * Loads option from configuration
	 * @param string $sOptionName Name of option
	 * @return upela Self
	 */
	protected function loadOption($sOptionName){

		$mValue = Configuration::get($sOptionName);

		$this->setOption($sOptionName, $mValue);

		return $this;

	} // loadOption

	/**
	 * Validates option
	 * @param string $sOptionName
	 * @param mixed $mValue
	 * @return array(boolean : true if variable is valid, array : array of error messages)
	 */
	protected function validateOption($sOptionName, $mValue){
		
		$bResult = true;
		
		$aErrors = array();
		
		if (isset($this->aConfigValidation[$sOptionName]) && is_array($this->aConfigValidation[$sOptionName])){
		
			foreach ($this->aConfigValidation[$sOptionName] as $aValidator){
				
				$cValidator = $aValidator[0];
	
				if (is_callable($cValidator)) {
					
					$bIsValid = call_user_func($cValidator, $mValue);
					
					if (!$bIsValid) {
						
						$bResult	= false;
						
						$aErrors[]	= isset($aValidator[1]) ? $this->l($aValidator[1]) : sprintf($this->l(self::MSG_INVALID_VALUE), $this->l($sOptionName), $mValue);
						
					} // if
					
				} // if
				
			} // foreach
		
		} // if
		
		return array($bResult, $aErrors);

	} // validateOption
	
	/**
	 * Validates all options
	 * @return array(boolean : true if all options are valid, array : array of error messages)
	 */
	protected function validateOptions(){
		
		return $this->validateOptionsFromArray($this->getOptions());
		
	} // validateOptions

	/**
	 * Validates all options form array (ie POST)
	 * @param array $aValues Array of option name => value
	 * @return array(boolean : true if all options are valid, array : array of error messages)
	 */
	protected function validateOptionsFromArray($aValues){
	
		$bResult = true;
	
		$aErrors = array();
			
		foreach (array_keys($this->aDefaultConfig) as $sOptionName) {
			
			if (!array_key_exists($sOptionName, $aValues)){
				
				continue;
				
			} // if
	
			list($bIsOptionValid, $aOptionValidationErrors) = $this->validateOption($sOptionName, $aValues[$sOptionName]);
	
			if (!$bIsOptionValid) {
	
				$bResult = false;
	
				$aErrors = array_merge($aErrors, $aOptionValidationErrors);
	
			}
				
		} // foreach
	
		return array($bResult, $aErrors);
	
	} // validateOptions
	
	# BACKOFFICE

	/**
	 * Main entry point for BO configuration screen
	 * Handles config display & updates
	 * @return string HTML with configuration form
	 */
	public function getContent(){
		
		$aInfos = array();
		$aWarnings = array();
		
		if (Tools::isSubmit('resendShipDemand')){
	
			if (Tools::getValue('id_order') && Tools::getValue('upela_packages') && Tools::getValue('upela_weight')){
			
				$bResult = $this->sendShipAndPickupDemand(Tools::getValue('id_order'), Tools::getValue('upela_weight'), Tools::getValue('upela_packages'));
			
				Tools::redirectAdmin('index.php?tab=AdminOrders&id_order='.(int)Tools::getValue('id_order').'&vieworder&token='.Tools::getAdminTokenLite('AdminOrders') .'&result=' . ($bResult ? 'ok' : 'ko'));	

			}
			
		} else if (Tools::isSubmit('submitUpela')){

			$this->postProcess();
			
			if (empty($this->aErrors)){
				$aInfos[] = $this->l('MSG_UPELA_CONFIG_SAVED');
			}				
		} else {
			
			list($_, $this->aErrors) = $this->validateOptions();
			
		} // if

		# maintenance

		// @todo add button
		// @todo add option "purge automatically on onfig"
		// @todo add cron task
		$this->purgeOfferts();

		# smarty assign
		
		

		$this->context->smarty->assign($this->getOptions());

		$this->context->smarty->assign('UPELA_VERSION', $this->version);

		$this->context->smarty->assign('order_states', $this->getOrderStates());

		$this->context->smarty->assign('choices', $this->getChoices());

		$this->context->smarty->assign('modes', $this->getModes());

		$this->context->smarty->assign('upela_module_path', $this->_path);
			
		$this->context->smarty->assign('pickup_demands', $this->getPickupDemands(date('Y-m-d')));
		
		$this->context->smarty->assign('averages', json_encode($this->getUpelaOrdersAverages()));
		
		$this->context->smarty->assign('errors', array_filter(array_unique($this->aErrors)));
	
		$this->context->smarty->assign('infos', array_filter(array_unique($aInfos)));
		
		$this->context->smarty->assign('warnings', array_filter(array_unique($aWarnings)));
		
		if ($this->isPrestashop16x()){
			
			$this->context->smarty->assign('current_url', $this->context->link->getAdminLink('AdminModules').'&configure=upela&tab_module=shipping_logistics&module_name=upela');
			
		}
		
		# fetch template
		
		$sTemplateName = $this->isPrestashop16x() ? '1.6/configuration' : 'configuration';

		return $this->display(__FILE__, 'views/templates/admin/' . $sTemplateName . '.tpl');

	} // getContent
	
	protected function sendShipAndPickupDemand($nOrderId, $fWeight, $nPackages){

		$bResult = false;

		$oOrder = new Order($nOrderId);
		
		if ($this->isCarrierUpela($nOrderId)){
			
			$oUpelaOffert = UpelaOffert::getByCartAndCarrierId($oOrder->id_cart, $oOrder->id_carrier);
			
			if ($oUpelaOffert) {
				
				$oUpelaOffert->weight = (float)$fWeight;
				
				$oUpelaOffert->packages = (int)$nPackages;
				
				$oUpelaOffert->update();
					
				$bResult = $this->sendShipDemand($nOrderId);
				
				$this->addPrivateMessage($nOrderId, $bResult ? $this->l(self::MSG_SHIP_DEMAND_SUCCESS) : $this->l(self::MSG_SHIP_DEMAND_FAIL));
				
				if ($bResult && !$this->wasPickupDemandSent(null, $oUpelaOffert->code_transporteur)){
				
					$bResult = $bResult && $this->sendPickupDemand($nOrderId, $oUpelaOffert->code_transporteur);
					
				} // if
							
			} // if
			
		} // if
		
		return $bResult;
		
	}
	
	protected function getPickupDemands($sDate){
		
		return UpelaPickupDemand::getByDate($sDate);
		
	}

	/**
	 * Returns API modes (production, test) for template display
	 * @return array of <array : <string : mode id => array ('name' => mode name, 'url' => mode url)>>
	 */
	protected function getModes(){

		return array(
				self::VALUE_MODE_PRODUCTION	=> array('name'=>$this->l(self::MSG_MODE_PRODUCTION), 'url'=> self::VALUE_API_URL_PRODUCTION),
				self::VALUE_MODE_TEST	=> array('name'=>$this->l(self::MSG_MODE_TEST), 'url'=> self::VALUE_API_URL_TEST)
		);

	} // getModes

	/**
	 * Returns offert selection types for template display
	 * @return array <string : selection id => string : selection name>
	 */
	protected function getChoices(){

		return array(
			self::VALUE_CHEAPEST	=> $this->l(self::MSG_CHEAPEST),
			self::VALUE_FASTEST		=> $this->l(self::MSG_FASTEST),
			self::VALUE_CHOOSE		=> $this->l(self::MSG_CHOOSE),
		);

	} // getChoices

	/**
	 * Returns order states with their names (localized)
	 * @return array <int : order state id => string : order state name>
	 */
	protected function getOrderStates(){

		$aResult = array();

		foreach (OrderState::getOrderStates((int)$this->context->language->id) as $aOrderState){

			$aResult[(int)$aOrderState['id_order_state']] = $aOrderState['name'];

		} // foreach

		return $aResult;

	} // getOrderStates

	/**
	 * Updates all options
	 * @todo add meaningful return
	 * @todo Add data validation
	 */
	protected function postProcess(){

		foreach (array_intersect_key($_POST, $this->aDefaultConfig) as $sOptionName => $mValue) {
			
			list($bIsValid, $aErrors) = $this->validateOption($sOptionName, $mValue);
			
			if ($bIsValid){
	
				$this->setOption($sOptionName, $mValue);
	
				$this->saveOption($sOptionName);
			
			} else {
				
				$this->aErrors = $this->aErrors + $aErrors;
				
			}

		} // foreach

		$this->updateCarrierUrls();

	} // postProcess
	
	# URL HANDLING

	/**
	 * Retrns url (dev or production) based on current config
	 * @return string
	 */
	protected function getBaseUrl(){

		return ($this->getOption(self::OPT_API_MODE) === self::VALUE_MODE_PRODUCTION ? self::VALUE_API_URL_PRODUCTION : self::VALUE_API_URL_TEST);

	} // getBaseUrl
	
	# CARRIER HANDLING

	/**
	 * Updates tracking urls after config update (when mode switched between dev & prod) 
	 */
	protected function updateCarrierUrls(){

		foreach (array($this->getOption(self::OPT_CHEAPEST_CARRIER_ID) => self::VALUE_CHEAPEST, $this->getOption(self::OPT_FASTEST_CARRIER_ID) => self::VALUE_FASTEST) as $nCarrierId => $sCarrierDefinitionKey){

			if ($nCarrierId) {

				$oCarrier = new Carrier($nCarrierId);

				$oCarrier->url = $this->getBaseUrl() . $this->aCarrierDefinitions[$sCarrierDefinitionKey]['url'];

			} // if

		} // foreach

	} // updateCarrierUrls

	# API HANDLING

	/**
	 * Creates new UpelaApi instance
	 * @return UpelaApi
	 */
	protected function createApiInstance(){

		require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'UpelaApi.php';

		$oApi = new UpelaApi();

		$oApi
			->setUrl($this->getBaseUrl() . self::VALUE_API_PATH)
			->setMethod($this->getOption(self::OPT_API_METHOD))
			->setLogin($this->getOption(self::OPT_API_LOGIN))
			->setPassword($this->getOption(self::OPT_API_PASSWORD))
			->setTimeout($this->getOption(self::OPT_WS_TIMEOUT));
		
		if ($this->getOption(self::OPT_API_MODE) === self::VALUE_MODE_TEST) {
			
			$oApi->activateLogging();
			
		}

		return $oApi;

	} // createApiInstance

	/**
	 * Gets UpelaApi instance (singleton). Creates its if necessary.
	 * @return UpelaApi
	 */
	protected function getApiInstance(){

		if ($this->oApi === null){

			$this->oApi = $this->createApiInstance();

		} // if

		return $this->oApi;

	} // getApiInstance

	# API CALLS

	/**
	 * Sends pickup demand
	 */
	protected function sendPickupDemand($nOrderId){

		$oOrder = new Order($nOrderId);

		$oUpelaOffert = $this->getOffert($oOrder->id_cart, $oOrder->id_carrier);

		if ($oUpelaOffert && $oUpelaOffert->id_expeditions){

			$aData = array(
					'id_expeditions' 	=> $oUpelaOffert->id_expeditions,
					'ship_from' 		=> $this->getShipFromData(),
					'colis' 			=> $this->getPickupPackageData(),
					'date_envoi'		=> date('Y-m-d', time() + (int)$this->getOption(self::OPT_DELIVERY_DELAY) * 86400),
					'mesures'			=> 'fr',
					'ready_time' 		=> $this->getOption(self::OPT_PICKUP_READY_TIME),
					'close_time' 		=> $this->getOption(self::OPT_PICKUP_CLOSE_TIME)

			);

			$aResult = $this->getApiInstance()->pickup($aData);

			// Saving date of pickup

			if ($aResult && isset($aResult['success']) && $aResult['success']){
				
				$oUpelaPickupDemand = new UpelaPickupDemand();
				
				$oUpelaPickupDemand->code_transporteur = $oUpelaOffert->code_transporteur;

				$oUpelaPickupDemand->date_send		   = date('Y-m-d H:i:s');
				
				return $oUpelaPickupDemand->save();

			} // if

		} // if
		
		return false;

	} // sendPickupDemand

	/**
	 * Gets rates for given address
	 * @param Address $oDeliveryAddress
	 * @return array Detailed list of shipment offerts
	 */
		protected function getRates(Cart $oCart){

		$sCacheId =sprintf('%d*%d*%f', $oCart->id, $oCart->id_address_delivery, round($oCart->getTotalWeight(), 3));
		
		if (!array_key_exists($sCacheId, self::$aRateCache)) {

			$aResult = $this->getApiInstance()->rate($this->getRateData($oCart));

			if ($aResult && is_array($aResult) && array_key_exists('success', $aResult) && $aResult['success']){

				self::$aRateCache[$sCacheId] = $aResult;

				return $aResult;

			} else {

				self::$aRateCache[$sCacheId] = array();

			} // if

		} // if

		return self::$aRateCache[$sCacheId];
		
	} // getRates

	/**
	 * Sends shipment demand for given order id
	 * @param integer $nOrderId
	 * @return boolean
	 */
	protected function sendShipDemand($nOrderId){
		
		$oOrder = new Order($nOrderId);

		$aData = $this->getShipData($oOrder);

		if ($aData) {

			$aResult = $this->getApiInstance()->ship($aData);
				
			if ($aResult && is_array($aResult) && isset($aResult['bordereau']['code'])) {

				// $this->addPrivateMessage($nOrderId, $aResult['bordereau']['code']);
				
				$oOrder->shipping_number = $aResult['bordereau']['code'];
				
				$this->updateTrackingNumber($oOrder->id, $oOrder->id_carrier, $aResult['bordereau']['code']);

				return $oOrder->save();

			} // if
			
			if ($aResult && $aResult['success']){
				
				return true;
				
			} // if

		} // if

		return false;

	} // sendShipDemand
	
	/**
	 * Updates tracking number for last entry in order_carriers with given id_order and id_carrier
	 * @param integer $nOrderId
	 * @param integer $nCarrierId
	 * @param string $sTrackingNumber
	 * @return boolean
	 */
	protected function updateTrackingNumber($nOrderId, $nCarrierId, $sTrackingNumber){
		
		$nLastOrderCarrierId = Db::getInstance()->getValue('SELECT id_order_carrier FROM ' . _DB_PREFIX_ . 'order_carrier WHERE 
				id_order = ' . intval($nOrderId) . ' AND id_carrier = ' . intval($nCarrierId) . ' ORDER BY id_order_carrier DESC'); 
		
		if ((int)$nLastOrderCarrierId > 0) {
			
			$sQuery = 'UPDATE '. _DB_PREFIX_ . 'order_carrier SET tracking_number="' . pSql($sTrackingNumber) . '" WHERE id_order_carrier = ' . intval($nLastOrderCarrierId);
			
			return Db::getInstance()->execute($sQuery);
			
		} // 
		
	}

	# DATA HANDLING

	/**
	 * Tests whether pickup demand was sent for given date (same day or after)
	 * @param string|null $sDate Date in format Y-m-d. If null, today's date is used
	 * @return boolean True if pickup demand was sent already
	 */
	protected function wasPickupDemandSent($sDate = null, $sExpeditorCode = null){

		if ($sDate === null){

			$sDate = date('Y-m-d');

		} // if
		
		$aPickupDemands = $sExpeditorCode ? UpelaPickupDemand::getByDateAndExpeditor($sDate, $sExpeditorCode)  : UpelaPickupDemand::getByDate($sDate);

		return count($aPickupDemands) > 0;

	} // wasPickupDemandSent

	/**
	 * Gets shipment destination data from address
	 * @param Address $oDeliveryAddress
	 * @return array of shipment destination data
	 * @todo Add data validation
	 */
	protected function getShipToData(Address $oDeliveryAddress){

		$oCustomer = new Customer($oDeliveryAddress->id_customer);

		$aResult = array(
			'code_pays' 	=> (string)Country::getIsoById((int)$oDeliveryAddress->id_country),
			'code_postal' 	=> (string)$oDeliveryAddress->postcode,
			'ville' 		=> (string)$oDeliveryAddress->city,
			'ligne1'		=> (string)$oDeliveryAddress->address1,
			'ligne2'		=> (string)$oDeliveryAddress->address2,
			'ligne3'		=> '',
			'societe'  		=> (string)$oDeliveryAddress->company ? (string)$oDeliveryAddress->company : '---',
			'nom'	  		=> sprintf('%s %s', $oDeliveryAddress->firstname, $oDeliveryAddress->lastname),
			'telephone'  	=> (string)$oDeliveryAddress->phone ? $oDeliveryAddress->phone : $oDeliveryAddress->phone_mobile,
			'email' 	 	=> (string)$oCustomer->email,
			'pro' 			=> property_exists($oDeliveryAddress, 'is_professional') ? (int)$oDeliveryAddress->is_professional : 0
		);

		return $aResult;

	} // getShipToData

	/**
	 * Gets shipment sender data from module config (default values are taken from shop data)
	 * @return array of shipment sender data
	 * @todo Add data validation
	 */
	protected function getShipFromData(){

		return array(
				'code_pays' 	=> (string)$this->getOption(self::OPT_SHIP_COUNTRY),
				'code_postal' 	=> (string)$this->getOption(self::OPT_SHIP_POSTAL_CODE),
				'ville' 		=> (string)$this->getOption(self::OPT_SHIP_CITY),
				'pro' 			=> (int)$this->getOption(self::OPT_SHIP_IS_PROFFESIONAL),
				'ligne1' 		=> (string)$this->getOption(self::OPT_SHIP_ADDRESS1),
				'ligne2' 		=> (string)$this->getOption(self::OPT_SHIP_ADDRESS2),
				'ligne3' 		=> (string)$this->getOption(self::OPT_SHIP_ADDRESS3),
				'societe'  		=> (string)$this->getOption(self::OPT_SHIP_COMPANY),
				'nom'	  		=> (string)$this->getOption(self::OPT_SHIP_NAME),
				'telephone'  	=> (string)$this->getOption(self::OPT_SHIP_PHONE),
				'email' 	 	=> (string)$this->getOption(self::OPT_SHIP_EMAIL),
		);

	} // getShipFromData

	/**
	 * Returns average number of packages in pickup
	 * @return integer Average number of packages (mini. 1)
	 */
	protected function getAveragePackagesNumber(){

		return max(1, (int)$this->getOption(self::OPT_AVERAGE_PACKAGES_NUMBER));

	} // getAveragePackagesNumber

	/**
	 * Gets package data for pickup call
	 * @return array Package data, taken from configuration
	 */
	protected function getPickupPackageData($fWeight = null, $nPackages = null){
		
		$nPackagesNumber = $nPackages ? $nPackages : $this->getAveragePackagesNumber();
		
		$nPackageWeight  = $fWeight ? $fWeight/$nPackages : max(1, (float)$this->getOption(self::OPT_AVERAGE_PACKAGE_WEIGHT));
		
		$aPackages = array();

		$aPackages[] = array(
			'nombre' => $nPackagesNumber,
			'poids'	 => $nPackageWeight,
			'x'		 => max(1, (float)$this->getOption(self::OPT_AVERAGE_DIMENSION_X)),
			'y'	 	 => max(1, (float)$this->getOption(self::OPT_AVERAGE_DIMENSION_Y)),
			'z'		 => max(1, (float)$this->getOption(self::OPT_AVERAGE_DIMENSION_Z)),
		);

		return $aPackages;

	} // getPickupPackageData

	/**
	 * Gets package data for pickup call
	 * @return array Package data, taken from configuration
	 */
	protected function getRatePackageData(Cart $oCart){

		$fTotalWeight = $oCart->getTotalWeight();
		
		$fAveragePackageWeight = (float)$this->getOption(self::OPT_AVERAGE_PACKAGE_WEIGHT) > 0 ? (float)$this->getOption(self::OPT_AVERAGE_PACKAGE_WEIGHT) : 1;


		$aPackages  = array();
		
		if ($fTotalWeight  > $fAveragePackageWeight){
			
			$nNumberOfPackages = max(1, floor($fTotalWeight / $fAveragePackageWeight));
				
			$aPackages[] = array(
					'nombre' => $nNumberOfPackages,
					'poids'	 => $fAveragePackageWeight,
					'x'		 => max(1, (float)$this->getOption(self::OPT_AVERAGE_DIMENSION_X)),
					'y'	 	 => max(1, (float)$this->getOption(self::OPT_AVERAGE_DIMENSION_Y)),
					'z'		 => max(1, (float)$this->getOption(self::OPT_AVERAGE_DIMENSION_Z)),
				);
		
		} else {
			
			$nNumberOfPackages = 0;
			
		} // if
		
		if ($fTotalWeight > $nNumberOfPackages * $fAveragePackageWeight) {
			
			$aPackages[] = array(
				'nombre' => 1,
				'poids'	 => $fTotalWeight - ($nNumberOfPackages * $fAveragePackageWeight),
				'x'		 => max(1, (float)$this->getOption(self::OPT_AVERAGE_DIMENSION_X)),
				'y'	 	 => max(1, (float)$this->getOption(self::OPT_AVERAGE_DIMENSION_Y)),
				'z'		 => max(1, (float)$this->getOption(self::OPT_AVERAGE_DIMENSION_Z)),
			);
			
		} // if
		
		return $aPackages;

	} // getRatePackageData

	/**
	 * Gets request data for 'ship' WS call
	 * @param Order $oOrder
	 * @return multitype:string multitype:string number  multitype: Ambigous <NULL, multitype:> multitype:string number NULL
	 */
	protected function getShipData(Order $oOrder){

		$oUpelaOffert = $this->getOffert($oOrder->id_cart, $oOrder->id_carrier);

		if (!$oUpelaOffert || !isset($oUpelaOffert->id_expeditions) || (int)$oUpelaOffert->id_expeditions <= 0){

			return array();

		} // if

		$oDeliveryAddress = new Address($oOrder->id_address_delivery);

		return array(
				'id_expeditions'	=>  (int)$oUpelaOffert->id_expeditions,
				'ship_from' 		=>  $this->getShipFromData(),
				'ship_to' 			=>  $this->getShipToData($oDeliveryAddress),
				'colis' 			=>  $this->getPickupPackageData($oUpelaOffert->weight, $oUpelaOffert->packages),
				'raison'			=>  $this->l(self::MSG_REASON),
				'contenu' 			=>  $this->getOption(self::OPT_CONTENT)
		);

	} // getRateData

	/**
	 * Gets request data for 'rate' WS call
	 * @param Address $oDeliveryAddress
	 * @return multitype:string multitype:string number  multitype: Ambigous <NULL, multitype:> multitype:string number NULL
	 */
	protected function getRateData(Cart $oCart){

		$oDeliveryAddress = new Address($oCart->id_address_delivery);

		return array(
			'ship_from' =>  $this->getShipFromData(),
			'ship_to' 	=>  $this->getShipToData($oDeliveryAddress),
			'colis' 	=>  $this->getRatePackageData($oCart),
			'date_envoi'=>  date('Y-m-d', time() + (int)$this->getOption(self::OPT_DELIVERY_DELAY) * 86400),
			'mesures'	=>  'fr',
			'selection' =>  $this->getOption(self::OPT_SELECTION)
		);

	} // getRateData

	/**
	 * Checks if order uses Upela as carrier
	 * @param integer $nOrderId Order id
	 * @return boolean True if order uses upela as carrier
	 */
	protected function isCarrierUpela($nOrderId){

		$sQuery = sprintf('SELECT c.external_module_name FROM `%1$sorders` o JOIN `%1$scarrier` c ON c.id_carrier = o.id_carrier WHERE o.id_order=%2$d', _DB_PREFIX_, (int)$nOrderId);

		return Db::getInstance()->getValue($sQuery) === $this->name;

	} // isCarrierUpela

	/**
	 * Gets statistics of upela orders for different periods
	 * @return multitype:multitype:number NULL string
	 */
	protected function getUpelaOrdersAverages(){	
		
		$aResult = array();
		
		foreach (array(self::VALUE_WEEK => self::MSG_WEEK, self::VALUE_MONTH => self::MSG_MONTH, self::VALUE_EVER => self::MSG_EVER) as $nDays => $sName) {
			
			$aRow = array();
			
			$aRow['orders']  		 = $this->getNumberOfUpelaOrders($nDays);

			$aRow['weight']  		 = $this->getUpelaOrdersWeight($nDays);
			
			$aRow['avg_weight']  	 = round($aRow['orders'] > 0 ? (float)($aRow['weight'] / $aRow['orders']) : 0, 3);

			$aRow['avg_packages']  	 = ceil($this->getOption(self::OPT_AVERAGE_PACKAGE_WEIGHT) > 0 ? $aRow['weight'] / $this->getOption(self::OPT_AVERAGE_PACKAGE_WEIGHT) : 0);
				
			$aRow['days']  	 		 = $nDays ? $nDays : '';
				
			$aRow['name']  			 = $this->l($sName);
			
			$aResult[] = $aRow;
				
		} // foreach
		
		return $aResult;
		
	}
	
	/**
	 * Gets weight of upela orders in period
	 * @param integer $nDays
	 * @return number
	 */
	protected function getUpelaOrdersWeight($nDays = null){

		$sQuery = sprintf('SELECT SUM(od.product_quantity * od.product_weight) FROM `%1$sorder_detail` od
				JOIN `%1$sorders` o ON o.id_order = od.id_order
				JOIN `%1$scarrier` c ON c.id_carrier = o.id_carrier  WHERE c.external_module_name = "%2$s"', _DB_PREFIX_, $this->name);

		if ((int)$nDays > 0) {
		
			$sQuery .= ' AND DATEDIFF( NOW(),  o.date_add) <= ' . (int)$nDays;

		} // if
		
		return (float)Db::getInstance()->getValue($sQuery);
	}
	
	/**
	 * Gets number of upela orders in period
	 * @param integer $nDays
	 * @return number
	 */
	protected function getNumberOfUpelaOrders($nDays = null){
	
		$sQuery = sprintf('SELECT COUNT(o.id_order) FROM `%1$sorders` o 
				JOIN `%1$scarrier` c ON c.id_carrier = o.id_carrier  WHERE c.external_module_name = "%2$s"', _DB_PREFIX_, $this->name);
	
		if ((int)$nDays > 0) { 
	
			$sQuery .= ' AND DATEDIFF(NOW(), o.date_add) <= ' . (int)$nDays;
	
		} // if
	
		return (int)Db::getInstance()->getValue($sQuery);
	}
	
	/**
	 * Gets id of the offert associated with the cart
	 * @param integer $nCartId Cart id
	 * @return UpelaOffert|null Offert data
	 */
	protected function getOffert($nCartId, $nCarrierId){

		return UpelaOffert::getByCartAndCarrierId($nCartId, $nCarrierId);

	} // getOffert

	/**
	 * Deletes all unused offerts if they are no longer actual
	 */
	protected function purgeOfferts(){

		$sQuery = sprintf('DELETE FROM `%1$supela_offert` WHERE choosen = 0 AND date_upd < DATE_SUB(NOW(), INTERVAL %d SECOND)', _DB_PREFIX_, $this->getOptions(self::OPT_OFFERT_LIFETIME));

		return Db::getInstance()->Execute($sQuery);

	} // purgeOfferts

	/**
	 * Checks whether carrier is a valid one
	 * @param integer $nCarrierId
	 * @return boolean
	 */
	protected function isCarrierValid($nCarrierId){

		# Not at all Upela
		# @todo handle desactivated carriers?
		if ((int)$this->getOption(self::OPT_CHEAPEST_CARRIER_ID) !== $nCarrierId && (int)$this->getOption(self::OPT_FASTEST_CARRIER_ID) !== $nCarrierId){

			return false;

		} // if

		# if we need only cheapest and that is not the case
		if ($this->getOption(self::OPT_SELECTION) === self::VALUE_CHEAPEST && (int)$this->getOption(self::OPT_CHEAPEST_CARRIER_ID) !== 	$nCarrierId) {

			return false;

		} // if

		# if we need only fastest and that is not the case
		if ($this->getOption(self::OPT_SELECTION) === self::VALUE_FASTEST && (int)$this->getOption(self::OPT_FASTEST_CARRIER_ID) !== $nCarrierId) {

			return false;

		} // if

		return true;

	} // isCarrierValid

	/**
	 * Gets column to sort on offerts
	 * @param integer $nCarrierId
	 * @return atring|null
 	 */
	protected function getSelectingColumn($nCarrierId){

		$sResult = null;

		if ((int)$this->getOption(self::OPT_CHEAPEST_CARRIER_ID) === (int)$this->id_carrier){

			$sResult = 'prix_ttc';

		} else if  ((int)$this->getOption(self::OPT_FASTEST_CARRIER_ID) === (int)$this->id_carrier){

			$sResult = 'date_livraison';

		} // if

		return $sResult;

	}  // getSelectingColumn

	/**
	* Gets offert from webservice
	* @param Cart $oCart
	* @param integer $nCarrierId
	* @param UpelaOffert|null $oUpelaOffert If passed, reuses existing object
	* @return UpelaOffert|null
	*/
	protected function getOffertFromWs($oCart, $nCarrierId, $oUpelaOffert = null) {

		$sColumn = $this->getSelectingColumn($nCarrierId);

		$aRates = $this->getRates($oCart);

		if ($aRates && is_array($aRates) && $aRates['success'] == true && $aRates['offres']){

			$aOfferts = $this->selectArrayElements($aRates['offres'], $sColumn);

			if (is_array($aOfferts) && count($aOfferts) > 0) {

				$aOffert = reset($aOfferts);

				return $aOffert + array('id_expeditions' => $aRates['id_expeditions'], 'id_commandes' => $aRates['id_commandes'], 'id_clients' => $aRates['id_clients']);

			} // if

		} 
			
		if ($aRates && is_array($aRates) && $aRates['success'] == false) {

			$sMessage = $this->getErrorMessage($aRates['errors']);

		} else {
			
			$sMessage = $this->l(self::MSG_RATE_DEMAND_FAILED);
			
		} // if
		if (!Validate::isMessage($sMessage)){
			
			$sMessage = str_replace(array('<','>','{','}','[',']'), ' ', $sMessage);
			
		} // if
			
		Logger::addLog($sMessage, 1, null, 'Cart', $oCart->id, true);

		return null;

	} // getOffertFromWs

	/**
	 * Transforms WS result into UpleaOffer object
	 * @param array $aOffert
	 * @param array $aRates
	 * @param Cart $oCart
	 * @param integer $nCarrierId
	 * @return UpelaOffert|null
	 */
	protected function createOffert(Cart $oCart, $nCarrierId) {

		$oUpelaOffert = new UpelaOffert();

		$oUpelaOffert->id_cart 			= (int)$oCart->id;
		$oUpelaOffert->id_carrier 		= (int)$nCarrierId;

		return $oUpelaOffert;


	}

	/**
	 * Fills UpelaOffert object with cart data
	 * @param UpelaOffert $oUpelaOffert
	 * @param Cart $oCart
	 * @return UpelaOffert UpelaOffert
	 */
	protected function fillCartData($oUpelaOffert, $oCart) {

		$oAddress = new Address((int)$oCart->id_address_delivery);

		$oUpelaOffert->id_address 		= (int)$oCart->id_address_delivery;
		$oUpelaOffert->postal_code 		= $oAddress->postcode;
		$oUpelaOffert->weight 			= $oCart->getTotalWeight();
		$oUpelaOffert->packages 		= ceil($oCart->getTotalWeight()/max(1,$this->getOption(self::OPT_AVERAGE_PACKAGE_WEIGHT)));
		
		return $oUpelaOffert;

	}

	/**
	 * Fills UpelaOffert object with offert data
	 * @param UpelaOffert $oUpelaOffert
	 * @param array $aOffert
	 * @return UpelaOffert UpelaOffert
	 */
	protected function fillOffertData($oUpelaOffert, $aOffert) {

		$oUpelaOffert->id_clients 		= $aOffert['id_clients'];
		$oUpelaOffert->id_commandes		= $aOffert['id_commandes'];
		$oUpelaOffert->id_expeditions	= $aOffert['id_expeditions'];
		$oUpelaOffert->id_offre			= (int)$aOffert['id'];
		$oUpelaOffert->code_service		= $aOffert['code_service'];
		$oUpelaOffert->service			= $aOffert['service'];
		$oUpelaOffert->code_transporteur= $aOffert['code_transporteur'];
		$oUpelaOffert->transporteur		= $aOffert['transporteur'];
		$oUpelaOffert->date_livraison	= $aOffert['date_livraison'];
		$oUpelaOffert->prix_ht			= (float)$aOffert['prix_ht'];
		$oUpelaOffert->tva				= (float)$aOffert['tva'];
		$oUpelaOffert->prix_ttc			= (float)$aOffert['prix_ttc'];
		$oUpelaOffert->code_devises		= $aOffert['code_devises'];

		return $oUpelaOffert;

	}

	/**
	* Gets offert for given cart and carrier. If order (ie weight or address id) changed or offert expired,
	* it performs webservice call, if not we are using stored offert
	* @param Cart $oCart
	* @param integer $nCarrierId
	* @return UpelaOffert|null
	*/
	protected function getOffertForCart($oCart, $nCarrierId){

		$oUpelaOffert = $this->getOffert($oCart->id, $nCarrierId);

		$bNeedsUpdate = false;

		// we are checking if
		// - there is offert at all
		// - address is the same (@todo what about changing address - add test for address date_upd vs offert date_add)
		// - weight is the same
		// - finally, offert is not too old
		if (!$oUpelaOffert){

			$oUpelaOffert = $this->createOffert($oCart, $nCarrierId);

			$bNeedsUpdate = true;

		} else {

			$oAddress = new Address((int)$oCart->id_address_delivery);

			if ((int)$oCart->id_address_delivery !== (int)$oUpelaOffert->id_address ||
					$oUpelaOffert->postal_code !== $oAddress->postcode ||
					round($oUpelaOffert->weight,3) !== round($oCart->getTotalWeight(),3) ||
					$oUpelaOffert->date_add < date('Y-m-d H:i:s', time() - (int)$this->getOption(self::OPT_OFFERT_LIFETIME))){

					$bNeedsUpdate = true;

			} // if

		} // if

		if ($bNeedsUpdate) {
			$aOffert = $this->getOffertFromWs($oCart, $nCarrierId);
			
			if ($aOffert && !empty($aOffert['prix_ttc'])) {
	
				$oUpelaOffert->choosen	= false;
	
				$this->fillCartData($oUpelaOffert, $oCart);
	
				$this->fillOffertData($oUpelaOffert, $aOffert);
	
				if ($oUpelaOffert->save()){
					
					return $oUpelaOffert;
					
				} 
			
			}
			
			return null;

		} // if

		return $oUpelaOffert;

	} // getOffertForCart

	# HOOKS
	public function hookDisplayAdminOrderTabShip($aParams){
		
		return $this->isPrestashop16x() ? $this->displayAdminOrderBlock(array('id_order'=>$aParams['order']->id)) : null; 

	}
	
	/**
	 * Displays extra carrier info (carrier name, service, date of delivery)
	 * @param array $aParams
	 */
	public function hookExtraCarrier($aParams){

		if (!$this->isValidController()){
	 		
	 		return false;
	 	}

		$aOfferts = array();

		$oCart = $aParams['cart'];
		
		foreach (array(self::OPT_CHEAPEST_CARRIER_ID, self::OPT_FASTEST_CARRIER_ID) as $sOptionName){
			$nCarrierId = (int)$this->getOption($sOptionName);

			$oUpelaOffert = $this->getOffert($oCart->id, $nCarrierId);
				
			if ($oUpelaOffert) {
				
				foreach ($aOfferts as $oExistingOffert){
						
					if ($oExistingOffert->transporteur == $oUpelaOffert->transporteur && 
						$oExistingOffert->service == $oUpelaOffert->service &&
						$oExistingOffert->prix_ttc == $oUpelaOffert->prix_ttc &&
						$oExistingOffert->date_livraison == $oUpelaOffert->date_livraison
						) {
						
						continue 2;
						
					} // if
						
				}
				
				$aOfferts[] = $oUpelaOffert;
				
			} // if
				
		} // foreach
		
		$this->context->smarty->assign('offerts', $aOfferts);
		
		$sTemplateName = ($this->isPrestashop14x() ? 'extra_carrier_14x' :  ($this->isPrestashop16x() ? '1.6/extra_carrier' : 'extra_carrier'));

		return $this->display(__FILE__, 'views/templates/front/'. $sTemplateName. '.tpl');

	} // hookExtraCarrier

	/*
	 ** Hook update carrier
	**
	*/
	public function hookUpdateCarrier($aParams){

		foreach (array(self::OPT_CHEAPEST_CARRIER_ID, self::OPT_FASTEST_CARRIER_ID) as $sOptionName) {

			if ((int)($aParams['id_carrier']) == (int)$this->getOption($sOptionName)){

				$this->setOption($sOptionName, (int)$aParams['carrier']->id);

				$this->saveOption($sOptionName);

			} // if

		} // foreach

	}
	
	public function hookNewOrder($aParams){
	
		return $this->hookActionValidateOrder($aParams);
	}
	
	/**
	 * Hook on order creation
	 * @param array $aParams
	 */
	public function hookActionValidateOrder($aParams){
		
		$oOrder = $aParams['order'];
		
		$oCart = new Cart($oOrder->id_cart);
		
		if ($this->isCarrierUpela($oOrder->id)){

			$oUpelaOffert = $this->getOffert($oCart->id, $oCart->id_carrier);
				
			if ($oUpelaOffert) {

				$aData = array(
				 'id_expeditions' 	=> (int)$oUpelaOffert->id_expeditions,
				 'id_offres' 		=> (int)$oUpelaOffert->id_offre
				);

				$aResult = $this->getApiInstance()->selectOffer($aData);

				if ($aResult && $aResult['success'] == true) {

					$oUpelaOffert->choosen = true;

					$oUpelaOffert->save();

				} // if

			} // if

		} // if

	}
	
	/**
	 * Displays upela block in BO
	 * @param unknown_type $aParams
	 */
	public function hookAdminOrder($aParams){
		
		return $this->isPrestashop16x() ? null : $this->displayAdminOrderBlock($aParams);
		
	}
	
	
	protected function displayAdminOrderBlock($aParams){
		
		$oOrder = new Order(isset($aParams['id_order']) ? $aParams['id_order'] : Order::getOrderByCartId($aParams['cart']->id));
		
		$oUpelaOffert = UpelaOffert::getByCartAndCarrierId($oOrder->id_cart, $oOrder->id_carrier);
		
		if ($oUpelaOffert){
				
			if (Tools::getValue('result') == 'ok') {
		
				$sUpelaMessage = $this->l(self::MSG_TRACKING_NUMBER_UPDATED);
		
				$sUpelaMessageClass = 'info';
		
			} else if (Tools::getValue('result') == 'ko') {
		
				$sUpelaMessage = $this->l(self::MSG_TRACKING_NUMBER_UPDATE_ERROR);
		
				$sUpelaMessageClass = $this->isPrestashop16x() ? 'alert alert-danger' : 'error';
		
			} else {
		
				$sUpelaMessage = '';
		
				$sUpelaMessageClass = '';
		
			}
				
			$this->context->smarty->assign('upela_message', $sUpelaMessage);
				
			$this->context->smarty->assign('upela_message_class', $sUpelaMessageClass);
		
			$this->context->smarty->assign('id_order', $oOrder->id);
		
			$this->context->smarty->assign('upela_offert', $oUpelaOffert);
		
			$this->context->smarty->assign('upela_module_uri', 'index.php?' . ($this->isPrestashop14x() ? 'tab' : 'controller') . '=AdminModules&configure=upela&token='.Tools::getAdminTokenLite('AdminModules'));
		
		} // if
		
		$sTemplateName = $this->isPrestashop16x() ? '1.6/order' : 'order';
			
		return $this->display(__FILE__, 'views/templates/admin/' . $sTemplateName . '.tpl');
		
	}
	
	# HELPERS
	
	/**
	 * Tests if we in this controller we can call ws
	 * Basically order. Lack of controller corresponds to payment page
	 * @return boolean
	 */
	protected function isValidController(){
		
		if ($this->isPrestashop14x()){
			
			global $smarty;

			$aControllers = preg_grep('/.*Controller\.php/', array_map('basename', get_included_files()));

			$aValues = array(
				'request'	=> isset($_REQUEST['controller']) ? $_REQUEST['controller'] : null,
				'smarty' 	=> isset($smarty) && is_callable(array($smarty, 'getTemplateVars')) ? $smarty->getTemplateVars('page_name') : null,	
				'server'	=> isset($_SERVER['PHP_SELF']) ? basename($_SERVER['PHP_SELF'], '.php') : null,
				'classes'	=> $aControllers ? str_replace('controller.php', '', strtolower(reset($aControllers))) : null,
			);
			
			$aValues = array_filter($aValues);

			if ($aValues){

				$aValuesCount = array_count_values($aValues);
				
				arsort($aValuesCount);
			
				$aValuesKeys = array_keys($aValuesCount);
					
				$sControllerKindaOf = reset($aValuesKeys );
				
			} else {

				$sControllerKindaOf = null;
			}

			return !$sControllerKindaOf || ($sControllerKindaOf == 'order' || $sControllerKindaOf == 'order-opc');
								
		} else {
		
			$oController = isset(Context::getContext()->controller) ? Context::getContext()->controller  : null;
			
			return $oController && (!isset($oController->php_self) || (isset($oController->php_self) && ($oController->php_self == 'order' || $oController->php_self == 'order-opc')));
				
		}
		
		
	}
	
	/**
	 * Flattens array with error messages from WS
	 * @param array|string $mErrors
	 * @return string
	 */
	protected function getErrorMessage($mErrors) {
		
		$aResult = array();
				
		if (!is_array($mErrors)){
			
			return (string)$mErrors;
			
		} // if
		
		foreach ($mErrors as $sKey => $mError) {
			
			if (is_array($mError)) {
				
				$aResult[] = $sKey . ' : ' . $this->getErrorMessage($mError);
				
			} else {
				
				$aResult[] = $sKey . ' : ' . (string)$mError;
				
			} // if
			
		} // foreach
				
		return implode(' , ', $aResult);
		
	}

	/**
	 * Adds private message to order
	 * @param integer $nOrderId
	 * @param string $sMessage
	 * @return boolean
	 */
	protected function addPrivateMessage($nOrderId, $sMessage){

		$oMessage = new Message();

		$oMessage->id_order = $nOrderId;

		$oMessage->private = true;

		$oMessage->message = $sMessage;

		return $oMessage->add();

	}

	/**
	 * Sorts given multidimensional array on specified column and picks N first elements
	 * @param array $aData Multidimensional array
	 * @param mixed $mColumn Index of column used to compare
	 * @param callable $cComparator Comparator function, compatible with usort (default strcmp)
	 * @param integer $nNumber Number of elements to pick (default : 1)
	 * @param boolean $bReverse If true, sorting order is reversed (default : false)
	 * @return array $nNumber (or less if $aData is shorter) of elements from the head of sorted $aData
	 * @todo Should be splitted into 2 methods (one for sorting and one for picking)
	 */
	protected function selectArrayElements($aData, $mColumn, $cComparator = 'strcmp', $nNumber = 1, $bReverse = false) {

		if (empty($aData) || !is_array($aData) || (int)$nNumber <= 0){

			return array();

		} // if

		$aSort = array();

		foreach ($aData as $mKey=>$aRow) {

			if (!is_array($aRow) || !array_key_exists($mColumn, $aRow)){

				continue;

			} // if

			$aSort[$mKey] = $aRow[$mColumn];

		} // foreach

		if (empty($aSort)){

			return array();

		} // if

		uasort($aSort, $cComparator);

		if ($bReverse) {

			array_reverse($aSort, true);

		} // if

		$aResult = array();

		foreach (array_slice($aSort, 0, (int)$nNumber, true) as $mKey=>$_){

			$aResult[$mKey] = $aData[$mKey];

		} // foreach

		return $aResult;

	} // selectArrayElements

	/**
	 * Gets ids of all languages
	 * @return array <int : language id>
	 */
	protected function getLanguagesIds(){

		$aResult= array();

		foreach (Language::getLanguages(false) as $aLanguage){

			$aResult[] = (int)$aLanguage['id_lang'];

		} // foreach

		return $aResult;

	} // getLanguagesIds

	/**
	 * Copy of Carrier::setGroups, not disponible before 1.5.4
	 * @param Carrier $oCarriers
	 * @param array $aGroups
	 * @param boolean $bDelete
	 * @return boolean
	 */
	protected function setGroups($oCarriers, $aGroups, $bDelete = true){

		if ($bDelete){

			Db::getInstance()->execute('DELETE FROM '._DB_PREFIX_.'carrier_group WHERE id_carrier = '. (int)$oCarriers->id);

		} // if

		if (!is_array($aGroups) || !count($aGroups)){

			return true;
		}

		$aValues = array();

		foreach ($aGroups as $nGroupId) {

			$aValues[] = sprintf('(%d,%d)', (int)$oCarriers->id, (int)$nGroupId);

		}

		$sQuery = 'INSERT INTO '._DB_PREFIX_.'carrier_group (id_carrier, id_group) VALUES ' . implode(',', $aValues);

		return Db::getInstance()->execute($sQuery);

	} // setGroups

	# ABSTRACT METHODS IMPLEMENTATIONS

	/**
	 * @see CarrierModule::getOrderShippingCost
	 */
	public function getOrderShippingCost($params, $shipping_cost){

		return false;

	} // getOrderShippingCost

	/**
	 * @see CarrierModule::getOrderShippingCostExternal
	 */
	 public function getOrderShippingCostExternal($params){
	 	 
	 	if (!$this->isValidController()){
	 			
	 		return false;
	 	}
	 	 
		if (!($params instanceof Cart)) {

			return false;

		} // if
		
		$oCart = $params;
		
		// @todo make it configurable? 
		if ($oCart->getTotalWeight() == 0){
			return false;
			
		} // if
		
		$nCarrierId = (int)$this->id_carrier;

		if (!$this->isCarrierValid($nCarrierId)){

			return false;

		} // if
		
		$oUpelaOffert = $this->getOffertForCart($oCart, $nCarrierId);
		
		if ($oUpelaOffert && (empty(self::$aCarrierOffert[$oUpelaOffert->id_offre]) || self::$aCarrierOffert[$oUpelaOffert->id_offre] === $nCarrierId)){

			self::$aCarrierOffert[$oUpelaOffert->id_offre] = $nCarrierId;
				
			return $oUpelaOffert->prix_ttc * (1 + $this->getOption(self::OPT_EXTRA_MARGE)/100);

		} // if
		
		return false;

	} // getOrderShippingCostExternal
	
	# PRESTASHHO VERSIONING
	
	protected function isPrestashop14x(){
		
		return version_compare(_PS_VERSION_, '1.5.0', 'lt');
		
	}
	
	protected function isPrestashop16x(){
	
		return version_compare(_PS_VERSION_, '1.6.0', 'ge');
	
	}

	# VALIDATORS
	
	/**
	 * Tests if variable is not empty
	 * @param mixed $mValue
	 * @return boolean
	 */
	public static function isNotEmpty($mValue){
		
		return !empty($mValue);
		
	} // isNotEmpty

	/**
	 * Tests if pickup date is valid (HHMM)
	 * @param mixed $mValue
	 * @return boolean
	 */
	public static function isPickupDate($mValue){
	
		return is_string($mValue) && strlen($mValue) == 4 && preg_match('/[0-9]{2}[0-9]{2}/', $mValue) && (int)$mValue>0 && (int)$mValue<2400;
	
	}

}