<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{upela}prestashop>upela_634f69cf7bae16226d67aa3536f53ca8'] = "Upela, la solution pour optimiser vos coûts de transport"; # MSG_DESCRIPTION
$_MODULE['<{upela}prestashop>upela_1630b5b492723481974a154f466d96ca'] = "Upela"; # MSG_DISPLAY_NAME
$_MODULE['<{upela}prestashop>upela_737cfc6481c6867039aa21fd9add7990'] = 'Upela - le moins cher'; # MSG_CARRIER_NAME_CHEAPEST
$_MODULE['<{upela}prestashop>upela_e9131c68721afb19fb63c08de738db60'] = 'Upela - le plus rapide'; # MSG_CARRIER_NAME_FASTEST
$_MODULE['<{upela}prestashop>upela_397fd61674d4851c3f35747daabfe87a'] = 'Délai de livraison'; # MSG_DELAY
$_MODULE['<{upela}prestashop>upela_e13e24fceb03fb7e645ed778d4410b2d'] = 'Le plus rapide'; # MSG_FASTEST
$_MODULE['<{upela}prestashop>upela_074ee8d672edbc10388f0a60f68125b2'] = 'Le moins cher'; # MSG_CHEAPEST
$_MODULE['<{upela}prestashop>upela_5234403c7dbff2d2d0939f8a50e03cfd'] = 'Choix du client'; # MSG_CHOOSE
$_MODULE['<{upela}prestashop>upela_37bda456f2e00e0a72b2d87c0cf0d631'] = 'Test'; # MSG_MODE_TEST
$_MODULE['<{upela}prestashop>upela_67d34fbdaa04fe17be1e805b1a6e4c1a'] = 'Production'; # MSG_MODE_PRODUCTION
$_MODULE['<{upela}prestashop>upela_2f0680c197c706bf97bcf74548032ee4'] = 'Demande de ramassage OK'; # MSG_SHIP_DEMAND_SUCCESS
$_MODULE['<{upela}prestashop>upela_f47786df723da755747d36457066cd18'] = 'Erreur de la demande de ramassage'; # MSG_SHIP_DEMAND_FAIL
$_MODULE['<{upela}prestashop>upela_2caaeb1190c472d64e9a678f92e1961e'] = "Les derniers 7 jours"; /*MSG_WEEK */
$_MODULE['<{upela}prestashop>upela_05093d64fd4d16a68d597ddde9e7f107'] = "Les derniers 30 jours"; /*MSG_MONTH */
$_MODULE['<{upela}prestashop>upela_c6939370b1bb2059b38bcff3bc39662e'] = "Depuis l'installation"; /*MSG_EVER */
$_MODULE['<{upela}prestashop>upela_62334fe00eedb9451441c3bc484990ef'] = 'Valeur invalide %2$s pour la variable %1$s'; /* MSG_INVALID_VALUE */
$_MODULE['<{upela}prestashop>upela_7e54b0a96320484f326cf496873937ea'] = 'Erreur de la demande de rating'; /* MSG_RATE_DEMAND_FAILED */
$_MODULE['<{upela}prestashop>upela_698141eccd73b14edb776a5744f1ccef'] = 'Commercial'; /* MSG_REASON */
$_MODULE['<{upela}prestashop>upela_ea6d1dbc26e8c0444f5223ba601a0f7d'] = 'Contenu des envois'; /* MSG_CONTENT */
$_MODULE['<{upela}prestashop>upela_4b07c33b9a299f953a2fc740b2f254c6'] = 'La génération du bordereau a réussi'; /* MSG_TRACKING_NUMBER_UPDATED */
$_MODULE['<{upela}prestashop>upela_46a9a3bdaa11443be39598fd930e0307'] = 'Erreur de la génération du bordereau'; /* MSG_TRACKING_NUMBER_UPDATE_ERROR */
$_MODULE['<{upela}prestashop>upela_fc5e26ab8e40020e7e7584903ffa00c8'] = 'Mode'; /* UPELA_API_MODE */
$_MODULE['<{upela}prestashop>upela_34d217eddf7ad05d7fb8e86d5d1eb923'] = 'Methode'; /* UPELA_API_METHOD */
$_MODULE['<{upela}prestashop>upela_a148b07597c81c16dc47ed0e44d0f262'] = 'Login'; /* UPELA_API_LOGIN */
$_MODULE['<{upela}prestashop>upela_2ca131102a87f02b732bb3d70668b006'] = 'Mot de passe'; /* UPELA_API_PASSWORD */
$_MODULE['<{upela}prestashop>upela_f848d91dcb9204055e36a8519bc44cd7'] = 'Nombre moyen de colis'; /* UPELA_AVERAGE_PACKAGES_NUMBER */
$_MODULE['<{upela}prestashop>upela_ca41837f586de81ac820d94eb1d6a77b'] = 'Poids moyen d\'un colis'; /* UPELA_AVERAGE_PACKAGE_WEIGHT */
$_MODULE['<{upela}prestashop>upela_8ec493f9002bcefff48d3d4b65675705'] = 'Dimension X'; /* UPELA_AVERAGE_DIMENSION_X */
$_MODULE['<{upela}prestashop>upela_51d667c144a1f2a115d4754b66882488'] = 'Dimension Y'; /* UPELA_AVERAGE_DIMENSION_Y */
$_MODULE['<{upela}prestashop>upela_c75d806157082b681680f85088db5be3'] = 'Dimension Z'; /* UPELA_AVERAGE_DIMENSION_Z */
$_MODULE['<{upela}prestashop>upela_1c66fe6724bf2ac227b1d81faa453767'] = 'Code iso du pays'; /* UPELA_SHIP_COUNTRY */
$_MODULE['<{upela}prestashop>upela_8396a58961fd1a7a76adceb403222fb6'] = 'Code postal'; /* UPELA_SHIP_POSTAL_CODE */
$_MODULE['<{upela}prestashop>upela_5a9139281d4045cff79c031719bf1dc9'] = 'Ville'; /* UPELA_SHIP_CITY */
$_MODULE['<{upela}prestashop>upela_6532715df2c1fb09c4a7db1c64f900eb'] = 'Adresse professionnelle'; /* UPELA_SHIP_IS_PROFFESIONAL */
$_MODULE['<{upela}prestashop>upela_fde6de25a0c6b2cd7101a9f15ce58aea'] = 'Adresse 1'; /* UPELA_SHIP_ADDRESS1 */
$_MODULE['<{upela}prestashop>upela_60a8a28f8f74c85cd6d2aa86be60fe70'] = 'Adresse 2'; /* UPELA_SHIP_ADDRESS2 */
$_MODULE['<{upela}prestashop>upela_5003de9373d6acacc76ae42f21ce595f'] = 'Adresse 3'; /* UPELA_SHIP_ADDRESS3 */
$_MODULE['<{upela}prestashop>upela_a26b90332842812ffc3b5cc9f1566fe0'] = 'Nom'; /* UPELA_SHIP_NAME */
$_MODULE['<{upela}prestashop>upela_ac4ea2d8b4c89bad3c333cb7c0d4e71e'] = 'Société'; /* UPELA_SHIP_COMPANY */
$_MODULE['<{upela}prestashop>upela_73ec13ae5754da9fdbf067bcec5582b6'] = 'Téléphone'; /* UPELA_SHIP_PHONE */
$_MODULE['<{upela}prestashop>upela_40fb6896196071a1492deef9955f9fce'] = 'Email'; /* UPELA_SHIP_EMAIL */
$_MODULE['<{upela}prestashop>upela_9ea2653521fe41754cb68dd303744728'] = 'Heure min d\'enlèvement'; /* UPELA_PICKUP_READY_TIME */
$_MODULE['<{upela}prestashop>upela_2930eeef82e049c6f531d39dbaa3f1af'] = 'Heure max d\'enlèvement'; /* UPELA_PICKUP_CLOSE_TIME */
$_MODULE['<{upela}prestashop>upela_c57fa52d9e3c6edd1dc132b817084a77'] = 'Date de la demande de ramassage'; /* UPELA_PICKUP_SENT_DATE */
$_MODULE['<{upela}prestashop>upela_c058a1b91ed500dcb7cdcbba744c9481'] = 'État declanchant la demande de ramassage'; /* UPELA_PICKUP_TRIGGER */
$_MODULE['<{upela}prestashop>upela_a25bfeec5a247ba830fd91c4bd697e82'] = 'Sélection'; /* UPELA_SELECTION */
$_MODULE['<{upela}prestashop>upela_ef7b94cb8b338873441bea0d0dfb2e80'] = 'État declanchant la demande de generation de bordereau'; /* UPELA_SHIP_TRIGGER */
$_MODULE['<{upela}prestashop>upela_702f436c7914aa5dc43ebc819cfaf989'] = 'Id du transporteur moins cher'; /* UPELA_CHEAPEST_CARRIER_ID */
$_MODULE['<{upela}prestashop>upela_067a3da25abf484f0d7ee6ac647b7d23'] = 'Id du transporteur plus rapide'; /* UPELA_FASTEST_CARRIER_ID */
$_MODULE['<{upela}prestashop>upela_ca1aab99baf0d92f83f4657fba898ed9'] = 'Temps de la vie du cache'; /* UPELA_OFFERT_LIFETIME */
$_MODULE['<{upela}prestashop>upela_d9a913e3f51ccd6c9118f505724dc7c7'] = 'Extra marge'; /* UPELA_EXTRA_MARGE */
$_MODULE['<{upela}prestashop>upela_06587fc649bb32c5673e2656a3b14ef8'] = 'Délai de livraison'; /* UPELA_DELIVERY_DELAY */
$_MODULE['<{upela}prestashop>upela_a862074a733d8ab668275c11682c16f1'] = 'Webservice timeout'; /* UPELA_WS_TIMEOUT */
$_MODULE['<{upela}prestashop>upela_ae1d9234b5056bfb7e75faacc3232f57'] = 'Contenu des envois'; /* UPELA_CONTENT */
$_MODULE['<{upela}prestashop>upela_e4d3ca5152523a543edaf83a2ce75337'] = 'Veuillez choisir l\'état declanchant de generation de bordereau'; /* MSG_ERROR_SHIP_TRIGGERT */
$_MODULE['<{upela}prestashop>upela_8f1de3ac33e36b3872f20ac464fb777c'] = 'Veuillez choisir l\'état declanchant la demande de ramassage'; /* MSG_ERROR_PICKUP_TRIGGER */

$_MODULE['<{upela}prestashop>upela_76b473c3b06a4bfb30ece4243f32fcdf'] = 'Veuillez saisir votre login'; /* MSG_ERROR_LOGIN */
$_MODULE['<{upela}prestashop>upela_55cc1c74bf2e572b4be9451aa2cb8b75'] = 'Veuillez saisir votre mot de passe'; /* MSG_ERROR_PASSWORD */




$_MODULE['<{upela}prestashop>upela_a8dbd3fd4237af6801f4b433986ace30'] = 'La configuration a été sauvegardée'; # MSG_UPELA_CONFIG_SAVED


$_MODULE['<{upela}prestashop>configuration_48688076588027f85ad98fc9b1004b4f'] = 'Informations sur ce module'; # MSG_MODULE_INFORMATION
$_MODULE['<{upela}prestashop>configuration_c5711e5b5555e33f4a97aec1eb6f9944'] = 'Module Upela version'; # MSG_MODULE_NAME_AND_VERSION
$_MODULE['<{upela}prestashop>configuration_096259656131f2e5953c1130d5bf25a2'] = 'Editeur'; # MSG_EDITOR
$_MODULE['<{upela}prestashop>configuration_792e385abd9ffd008bc9d3151517b38f'] = 'agence web certifiée par PrestaShop'; # MSG_KIWIK
$_MODULE['<{upela}prestashop>configuration_7c7177f5bef0ef7b42214ddbef08a2a4'] = 'Studio Kiwik'; # MSG_EDITOR_CERTIFIED_PRESTASHOP
$_MODULE['<{upela}prestashop>configuration_03e3c017688b09798543c160913b2b7c'] = 'Délai de livraison (jours)'; # MSG_UPELA_DELIVERY_DELAY
$_MODULE['<{upela}prestashop>configuration_77c1684be08501543bf73ed161a7f68a'] = 'Extra marge (%)'; # MSG_UPELA_EXTRA_MARGE
$_MODULE['<{upela}prestashop>configuration_0b68207503027193e5e75cff315725e9'] = "Upela"; /*MSG_UPELA_TITLE*/
$_MODULE['<{upela}prestashop>configuration_f14281779c3f51933819a8c7c9ab4741'] = "Informations générales"; /*MSG_UPELA_INTRO_TITLE*/
$_MODULE['<{upela}prestashop>configuration_6f71edac8d96958abdcd4edb5f723d3a'] = "Upela, la solution pour optimiser vos coûts de transport"; /*MSG_UPELA_INTRO*/
$_MODULE['<{upela}prestashop>configuration_230267ee074a2f120a080b244e61f536'] = "Identifiants du compte UPELA"; /*MSG_UPELA_API_CREDENTIALS*/
$_MODULE['<{upela}prestashop>configuration_d0f83f36699e9a694f366dee6e5edb5c'] = "Login"; /*MSG_UPELA_API_LOGIN*/
$_MODULE['<{upela}prestashop>configuration_a4b2dee42ce7a4d6c9266a76d3edadb1'] = "Mot de passe"; /*MSG_UPELA_API_PASSWORD*/
$_MODULE['<{upela}prestashop>configuration_0509f0ffff11a89872aeb0995a37ad93'] = "Mode"; /*MSG_UPELA_API_MODE*/
$_MODULE['<{upela}prestashop>configuration_39c750827a747824e9848068ad2546bb'] = "Transporteur"; /*MSG_UPELA_CHOICE*/
$_MODULE['<{upela}prestashop>configuration_9ee33b585082509d302022aafd68e2e3'] = "Sélection"; /*MSG_UPELA_SELECTION*/
$_MODULE['<{upela}prestashop>configuration_41885cb8e7b3ca1c13b1540da044902f'] = "Adresse de départ"; /*MSG_UPELA_SHIPPING_ADDRESS*/
$_MODULE['<{upela}prestashop>configuration_b57745c30d9b116ca88ef34a3a3097f8'] = "Code iso du pays"; /*MSG_UPELA_SHIP_COUNTRY*/
$_MODULE['<{upela}prestashop>configuration_344b8efec694531e684b3d792d4e5501'] = "Code postal"; /*MSG_UPELA_SHIP_POSTAL_CODE*/
$_MODULE['<{upela}prestashop>configuration_350ed8efedd7ba8690c32478d41126fd'] = "Ville"; /*MSG_UPELA_SHIP_CITY*/
$_MODULE['<{upela}prestashop>configuration_dd849b2f3113e41ccecdbe79b35c61fb'] = "Adresse 1"; /*MSG_UPELA_SHIP_ADDRESS1*/
$_MODULE['<{upela}prestashop>configuration_026414ca2891e86b4e229fc5bd37bcd1'] = "Adresse 2"; /*MSG_UPELA_SHIP_ADDRESS2*/
$_MODULE['<{upela}prestashop>configuration_64038db0ee937109c9fd33da46e61da2'] = "Adresse 3"; /*MSG_UPELA_SHIP_ADDRESS3*/
$_MODULE['<{upela}prestashop>configuration_2053b9d6da2a74e46e980525b2aa67f8'] = "Nom"; /*MSG_UPELA_SHIP_NAME*/
$_MODULE['<{upela}prestashop>configuration_77e7486461a7205b32edf59f9b126f15'] = "Téléphone"; /*MSG_UPELA_SHIP_PHONE*/
$_MODULE['<{upela}prestashop>configuration_40fb6896196071a1492deef9955f9fce'] = "Email"; /*UPELA_SHIP_EMAIL*/
$_MODULE['<{upela}prestashop>configuration_ac4ea2d8b4c89bad3c333cb7c0d4e71e'] = "Société"; /*UPELA_SHIP_COMPANY*/
$_MODULE['<{upela}prestashop>configuration_485be6eb1afefe4b71f052bdc9bdb8b1'] = "Adresse professionnelle"; /*MSG_UPELA_SHIP_IS_PROFFESIONAL*/
$_MODULE['<{upela}prestashop>configuration_7235c912f8c0b49301fff25cc911338e'] = "Oui"; /*MSG_YES*/
$_MODULE['<{upela}prestashop>configuration_45349d0bf5c830088441c05a32d65cb7'] = "Non"; /*MSG_NO*/
$_MODULE['<{upela}prestashop>configuration_44edb1f1cf0b2f02e204896c3c637617'] = "Ramassage"; /*MSG_UPELA_PICKUP*/
$_MODULE['<{upela}prestashop>configuration_ef3b8d6aa5d7214367f281d857217b4b'] = "État"; /*MSG_UPELA_PICKUP_TRIGGER*/
$_MODULE['<{upela}prestashop>configuration_cddf61c48a61ae27bf7620520c6f92ee'] = "Choisir..."; /*MSG_UPELA_CHOOSE_OPTION*/
$_MODULE['<{upela}prestashop>configuration_201eb9119c8f21abbfa81d3462e04b5f'] = "Nombre moyen de colis par ramassage"; /*MSG_UPELA_AVERAGE_PACKAGES_NUMBER*/
$_MODULE['<{upela}prestashop>configuration_3769518fa1d77920bd6ff61c6b1ec085'] = "Poids moyen d'un colis (kg)"; /*MSG_UPELA_AVERAGE_PACKAGE_WEIGHT*/
$_MODULE['<{upela}prestashop>configuration_5d3e918f73f5ec6482cc0f9168bae45c'] = "Dimensions (cm)"; /*MSG_UPELA_AVERAGE_DIMENSIONS*/
$_MODULE['<{upela}prestashop>configuration_5d74e531d475d0ff0b7347572f2dd048'] = "X (cm)"; /*MSG_UPELA_AVERAGE_DIMENSION_X*/
$_MODULE['<{upela}prestashop>configuration_a8e59dd791a74fc7cf3e9bdf073d2179'] = "Y (cm)"; /*MSG_UPELA_AVERAGE_DIMENSION_Y*/
$_MODULE['<{upela}prestashop>configuration_62898c5304977f6f56ec0b4130996402'] = "Z (cm)"; /*MSG_UPELA_AVERAGE_DIMENSION_Z*/
$_MODULE['<{upela}prestashop>configuration_36dc2744070fb3c476a5303b4e687cd9'] = "Heure min d'enlèvement souhaitée"; /*MSG_UPELA_PICKUP_READY_TIME*/
$_MODULE['<{upela}prestashop>configuration_554dcec781f1be35c5f494fa8dc7ecee'] = "Heure max d'enlèvement souhaitée"; /*MSG_UPELA_PICKUP_CLOSE_TIME*/
$_MODULE['<{upela}prestashop>configuration_a6e8ba9c74bafd5aab142ce947668aef'] = "Génération du bordereau"; /*MSG_UPELA_SHIP*/
$_MODULE['<{upela}prestashop>configuration_ce6b1f44bcc7be19805cb35c3213b9b3'] = "État"; /*MSG_UPELA_SHIP_TRIGGER*/
$_MODULE['<{upela}prestashop>configuration_70617af688d8bc25a8b7c9a2b2d37a79'] = "Sauvegarder"; /*MSG_SAVE*/
$_MODULE['<{upela}prestashop>configuration_3b7f4c79706e81a1cf1807f16e77088d'] = "Dernière demande de ramassage"; /*MSG_UPELA_LAST_PICKUP_DATE*/
$_MODULE['<{upela}prestashop>configuration_f5effd02448456f7b79550b0bb4e34c0'] = "Format HHMM"; /* MSG_UPELA_PICKUP_TIME_FORMAT */
$_MODULE['<{upela}prestashop>configuration_9d959c412cbab0ced44244447a6632c1'] = "Poids moyen d'une commande"; /* MSG_UPELA_AVERAGE_ORDER_WEIGHT */
$_MODULE['<{upela}prestashop>configuration_b0b486bb26c91e530cc96376ba490041'] = "Plus d'info sur le site"; /*  */
$_MODULE['<{upela}prestashop>extra_carrier_2227b6cab59f117d30901a9f8046c93f'] = "Livraison possible à partir de"; /*MSG_UPELA_DELIVERY_DATE*/
$_MODULE['<{upela}prestashop>extra_carrier_14x_2227b6cab59f117d30901a9f8046c93f'] = "Livraison possible à partir de"; /*MSG_UPELA_DELIVERY_DATE*/
$_MODULE['<{upela}prestashop>configuration_031038d40ab5ced86c3de6ed00b69387'] = "Contenu des envois"; /*MSG_UPELA_CONTENT*/
$_MODULE['<{upela}prestashop>order_7f557c5c984da033a2840e5c77a4a840'] = "# Expedition"; /* MSG_UPELA_EXPEDITION_ID */
$_MODULE['<{upela}prestashop>order_cd4b9e5598b28fc67b889ea3850e9e63'] = "# offert"; /* MSG_UPELA_OFFERT_ID */
$_MODULE['<{upela}prestashop>order_81dabe8f4602a4d8e5ac8f644bf57112'] = "Transporteur"; /* MSG_UPELA_CARRIER */
$_MODULE['<{upela}prestashop>order_9bcbaf6cdae7e29e6411f60d5731b61d'] = "Service"; /* MSG_UPELA_SERVICE */
$_MODULE['<{upela}prestashop>order_2227b6cab59f117d30901a9f8046c93f'] = "Date de livraison"; /* MSG_UPELA_DELIVERY_DATE */
$_MODULE['<{upela}prestashop>order_7812867af8757b27831c97e6848bba78'] = "Nombre de colis"; /* MSG_UPELA_PACKAGES */
$_MODULE['<{upela}prestashop>order_2e99158b74b42ca3733717961e46efdf'] = "Poids total"; /* MSG_UPELA_WEIGHT */
$_MODULE['<{upela}prestashop>order_e6ccfeaad94d3ac1e3c6868e4ecbb831'] = "Générer le bordereau"; /* MSG_UPELA_RESEND_SHIPPING_DEMAND */


