<?php

	require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config.php';

	$api = new UpelaApi();

	$api
		->setUrl(UPELA_API_URL)
		->setMethod(UPELA_API_METHOD)
		->setLogin(UPELA_LOGIN) // set here you Upela account login
		->setPassword(UPELA_PASSWORD); // set here you Upela account password
	
  $request = array(
    'shipment_id' => 1294154,
    'ship_from' => array(
      'company' => 'My company',
      'name' => 'Prénom Nom',
      'phone' => '0101010101',
      'email' => 'xxxxx@xxxxx.com',
      'address1' => '17bis rue la Boétie',
      'address2' => '...',
      'country_code' => 'FR',
      'postcode' => '75008',
      'city' => 'Paris',
      'pro' => 1,
    ),
    'ship_to' => array(
      'company' => 'Company XYZ',
      'name' => 'Prénom Nom',
      'phone' => '0101010101',
      'email' => 'xxxxx@xxxxx.com',
      'address1' => '...',
      'address2' => '...',
      'country_code' => 'FR',
      'postcode' => '31000',
      'city' => 'Toulouse',
      'pro' => 1,
    ),
    'reason' => 'Commercial',
    'content' => 'Contenu de l\'envoi',
    'label_format' => 'PDF', // possible values are PDF or ZPL
  );
  
  $response = $api->ship($request);

  print_r($response);
  
/*
SAMPLE REPONSE :

Array
(
    [customer_id] => 147497
    [shipment_id] => 1294154
    [order_id] => 1280731
    [carrier_code] => COURSIER
    [carrier_name] => Coursier
    [waybill] => Array
        (
            [code] => 129415448372
            [url] => https://dev.upela.com/waybills/129415448372.PDF
        )

    [tracking_number] => UPELA129415448372
    [success] => 1
    [errors] => Array
        (
        )

)

*/

?>