STEPS

1) Ensure you have a Upela account (login / password) and that this account has been authorized to use the API
(write an email to contact@upela.com if you need further information)


2) Edit config.php file to define :
- UPELA_API_URL : either UpelaApi::API_URL_TEST (in test mode) or UpelaApi::API_URL_PRODUCTION (in production)
- UPELA_LOGIN : your Upela account login
- UPELA_PASSWORD : your Upela account password

3) You can run the following PHP samples to test the different Upela API methods.
Please run them in the order listed below as request parameters can depend on the previous script response.
- rate.php
- select_offer.php
- ship.php
- pickup.php
- cancel_pickup.php
- track.php

In each script, you can edit the request parameters ($request).
A sample response is given in each script (in comments).


