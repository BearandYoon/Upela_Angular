<?php

	require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config.php';

	$api = new UpelaApi();

	$api
		->setUrl(UPELA_API_URL)
		->setMethod(UPELA_API_METHOD)
		->setLogin(UPELA_LOGIN) // set here you Upela account login
		->setPassword(UPELA_PASSWORD); // set here you Upela account password
	
  $request = array(
    'shipment_id' => 1294154,
    'offer_id' => 8147713,
  );
  
  $response = $api->selectOffer($request);

  print_r($response);

/*
SAMPLE REPONSE :

Array
(
    [customer_id] => 147497
    [success] => 1
    [errors] => Array
        (
        )

)
*/

?>