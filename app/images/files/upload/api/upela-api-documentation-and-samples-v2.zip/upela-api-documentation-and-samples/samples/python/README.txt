STEPS

1) Ensure you have a Upela account (login / password) and that this account has been authorized to use the API
(write an email to contact@upela.com if you need further information)


2) Edit upela.py file (function exec_request) to define :
- Upela API url : either https://dev.upela.com/api/ (in test mode) or https://www.upela.com/api/ (in production)
- Your Upela account login
- Your Upela account password

3) You can run the following Pyhton sample to test the different Upela API methods.
Please run them in the order listed below as request parameters can depend on the previous script response.
- rate
- select_offer
- ship
- pickup
- cancel_pickup
- track



