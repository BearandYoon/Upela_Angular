<?php

	require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config.php';

	$api = new UpelaApi();

	$api
		->setUrl(UPELA_API_URL)
		->setMethod(UPELA_API_METHOD)
		->setLogin(UPELA_LOGIN) // set here you Upela account login
		->setPassword(UPELA_PASSWORD); // set here you Upela account password
	
  $request = array(
    'shipment_id' => 1291140,
  );
  
  $response = $api->track($request);

  print_r($response);
  

/*
SAMPLE REPONSE :

Array
(
    [customer_id] => 147497
    [shipment_id] => 1291140
    [events] => Array
        (
            [0] => Array
                (
                    [date] => 2016-08-11 17:23:00
                    [location] => 24340 VIEUX MAREUIL (France)
                    [code] => KB
                    [description] => Delivered
                )

            [1] => Array
                (
                    [date] => 2016-08-11 04:41:00
                    [location] =>  CARBON BLANC, BORDEA (France)
                    [code] => DS
                    [description] => Out For Delivery
                )

            [2] => Array
                (
                    [date] => 2016-08-11 04:40:00
                    [location] =>  CARBON BLANC, BORDEA (France)
                    [code] => AR
                    [description] => Arrival Scan
                )

            [3] => Array
                (
                    [date] => 2016-08-10 22:01:00
                    [location] =>  CHILLY MAZARIN, PARI (France)
                    [code] => DP
                    [description] => Departure Scan
                )

            [4] => Array
                (
                    [date] => 2016-08-10 21:07:00
                    [location] =>  CHILLY MAZARIN, PARI (France)
                    [code] => AR
                    [description] => Arrival Scan
                )

            [5] => Array
                (
                    [date] => 2016-08-10 20:15:00
                    [location] =>  ST OUEN (France)
                    [code] => DP
                    [description] => Departure Scan
                )

            [6] => Array
                (
                    [date] => 2016-08-10 18:45:00
                    [location] =>  ST OUEN (France)
                    [code] => OR
                    [description] => Origin Scan
                )

            [7] => Array
                (
                    [date] => 2016-08-09 09:53:00
                    [location] =>   (France)
                    [code] => MP
                    [description] => Order Processed: Ready for UPS
                )

        )

    [success] => 1
    [errors] => Array
        (
        )

)


*/

?>