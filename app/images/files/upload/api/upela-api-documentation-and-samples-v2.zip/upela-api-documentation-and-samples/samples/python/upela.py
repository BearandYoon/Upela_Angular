#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import json
import requests

def exec_request(method, request):
  url = 'https://dev.upela.com/api/v2/' ## test url
  #url = 'https://www.upela.com/api/v2/' ## production url
  url = url + method + "/"
  request["account"] = {
    "login":"your Upela account login",
    "password":"your Upela account password"
  }
  r = requests.post(url, data={'request': json.dumps(request)})
  #print r.status_code
  #print r.text
  return r.json()

def rate():
  request = {
      "ship_from":{
          "country_code":"FR",
          "postcode":"75008",
          "city":"Paris",
          "pro":1
      },
      "ship_to":{
          "country_code":"FR",
          "postcode":"31000",
          "city":"Toulouse",
          "pro":0
      },
      "parcels":[
          {"number":2, "weight":1, "x":10, "y":10, "z":10},
          {"number":1, "weight":1.5, "x":10, "y":10, "z":10}
      ],
      "shipment_date":"2016-04-05",
      "unit":"fr",
      "selection":"cheapest_and_fastest"
  }
  print exec_request("rate", request)

def select_offer():
  request = {
      "shipment_id":1054264,
      "offer_id":5834305
  }
  print exec_request("select_offer", request)

def ship():
  request = {
      "shipment_id":1054264,
      "ship_from":{
          "company":"My company",
          "name":"Prénom Nom",
          "phone":"0101010101",
          "email":"xxxxx@xxxxx.com",
          "address1":"17bis rue la Boétie",
          "address2":"...",
          "country_code":"FR",
          "postcode":"75008",
          "city":"Paris",
          "pro":1
      },
      "ship_to":{
          "company":"Company XYZ",
          "name":"Prénom Nom",
          "phone":"0101010101",
          "email":"xxxxx@xxxxx.com",
          "address1":"...",
          "address2":"...",
          "country_code":"FR",
          "postcode":"31000",
          "city":"Toulouse",
          "pro":0
      },
      "reason":"Commercial",
      "content":"Contenu de l'envoi",
      "label_format":"PDF" # possible values are PDF or ZPL
  }
  print exec_request("ship", request)

def pickup():
  request = {
      "shipment_id":1054264,
      "ship_from":{
          "company":"My company",
          "name":"Prénom Nom",
          "phone":"0101010101",
          "email":"xxxxx@xxxxx.com",
          "address1":"17bis rue la Boétie",
          "address2":"...",
          "country_code":"FR",
          "postcode":"75008",
          "city":"Paris",
          "pro":1
      },
      "parcels":[
          {"number":2, "weight":1, "x":10, "y":10, "z":10},
          {"number":1, "weight":1.5, "x":10, "y":10, "z":10}
      ],
      "unit":"fr",
      "shipment_date":"2016-04-05",
      "ready_time":"1100",
      "close_time":"1800"
  }
  print exec_request("pickup", request)

def cancel_pickup():
  request = {
      "shipment_id":1054264
  }
  print exec_request("cancel_pickup", request)

def track():
  request = {
      "shipment_id":1054264
  }
  print exec_request("track", request)

rate()
#select_offer()
#ship()
#pickup()
#cancel_pickup()
#track()

