<?php

	require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config.php';

	$api = new UpelaApi();

	$api
		->setUrl(UPELA_API_URL)
		->setMethod(UPELA_API_METHOD)
		->setLogin(UPELA_LOGIN) // set here you Upela account login
		->setPassword(UPELA_PASSWORD); // set here you Upela account password
	
  $request = array(
    'ship_from' => array(
      'country_code' => 'FR',
      'postcode' => '75008',
      'city' => 'Paris',
      'pro' => 1,
    ),
    'ship_to' => array(
      'country_code' => 'FR',
      'postcode' => '31000',
      'city' => 'Toulouse',
      'pro' => 1,
    ),
    'parcels' => array(
      array('number' => 2, 'weight' => 1, 'x' => 10, 'y' => 10, 'z' => 10),    
      array('number' => 1, 'weight' => 1.5, 'x' => 10, 'y' => 10, 'z' => 10),    
    ),
    'shipment_date' => '2016-08-16',
    'unit' => 'fr',
    'selection' => 'cheapest_and_fastest', // possible values : all, cheapest_and_fastest, cheapest, fastest 
  );
  
  $response = $api->rate($request);

  print_r($response);

/*
SAMPLE REPONSE :

Array
(
    [customer_id] => 147497
    [order_id] => 1280731
    [shipment_id] => 1294154
    [success] => 1
    [offers] => Array
        (
            [0] => Array
                (
                    [carrier_code] => CHRONOPOST
                    [carrier_name] => Chronopost
                    [service_code] => 16
                    [service_name] => Chrono 18
                    [shipment_date] => 2016-08-16
                    [delivery_date] => 2016-08-17 18:00:00
                    [price_excl_tax] => 7.89
                    [vat_rate] => 20
                    [price_incl_tax] => 9.47
                    [currency] => EUR
                    [allow_pickup] => 0
                    [allow_dropoff] => 1
                    [delivery_to_collection_point] => 0
                    [id] => 8147712
                )

            [1] => Array
                (
                    [carrier_code] => COURSIER
                    [carrier_name] => Coursier
                    [service_code] => 01
                    [service_name] => Coursier
                    [shipment_date] => 2016-08-16
                    [delivery_date] => 2016-08-16 16:00:00
                    [vat_rate] => 20
                    [price_excl_tax] => 511.25
                    [price_incl_tax] => 613.5
                    [currency] => EUR
                    [allow_pickup] => 1
                    [allow_dropoff] => 0
                    [delivery_to_collection_point] => 0
                    [id] => 8147713
                )

        )

    [errors] => Array
        (
        )

)
*/

?>