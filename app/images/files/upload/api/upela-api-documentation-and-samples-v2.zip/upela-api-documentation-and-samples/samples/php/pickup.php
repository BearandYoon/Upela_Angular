<?php

	require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config.php';

	$api = new UpelaApi();

	$api
		->setUrl(UPELA_API_URL)
		->setMethod(UPELA_API_METHOD)
		->setLogin(UPELA_LOGIN) // set here you Upela account login
		->setPassword(UPELA_PASSWORD); // set here you Upela account password
	
  $request = array(
    'shipment_id' => 1294154,
    'ship_from' => array(
      'company' => 'My company',
      'name' => 'Prénom Nom',
      'phone' => '0101010101',
      'email' => 'xxxxx@xxxxx.com',
      'address1' => '17bis rue la Boétie',
      'address2' => '...',
      'country_code' => 'FR',
      'postcode' => '75008',
      'city' => 'Paris',
      'pro' => 1,
    ),
    'parcels' => array(
      array('number' => 2, 'weight' => 1, 'x' => 10, 'y' => 10, 'z' => 10),    
      array('number' => 1, 'weight' => 1.5, 'x' => 10, 'y' => 10, 'z' => 10),    
    ),
    'unit' => 'fr',
    'shipment_date' => '2016-08-16',
    'ready_time' => '1100',
    'close_time' => '1800',
  );
  
  $response = $api->pickup($request);

  print_r($response);

/*
SAMPLE REPONSE :

Array
(
    [customer_id] => 147497
    [shipment_id] => 1294154
    [carrier_code] => COURSIER
    [carrier_name] => Coursier
    [reservation_number] => 129415448372
    [success] => 1
    [errors] => Array
        (
        )

)

*/

?>