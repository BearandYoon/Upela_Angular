	   	<div class="section">
            <h2><?php echo __( 'Step 1 : Insert your information in the section Settings of this plugin', 'upela' ); ?></h2>
                <p><?php echo __( 'Configure the credentials to access your store from Upela', 'upela' ); ?></p>
                <p><?php echo __( 'Configure your store address', 'upela' ); ?></p>
        </div><!-- .section -->
	   	<div class="section">
            <h2><?php echo __( 'Step 2 : Configure your store (Username, Password, Module URL) in Upela', 'upela' ); ?></h2>
			<p><img src="<?php echo PLUGIN_URL_UPELAWORDPRESS; ?>img/image01.png" style="text-align: center; max-width: 800px;"/></p>
			<p><img src="<?php echo PLUGIN_URL_UPELAWORDPRESS; ?>img/image02.png" style="text-align: center; max-width: 800px;"/></p>
			<p><img src="<?php echo PLUGIN_URL_UPELAWORDPRESS; ?>img/image03.png" style="text-align: center; max-width: 800px;"/></p>
        </div><!-- .section -->