<?php echo '<?xml version="1.0" standalone="yes" ?>'; ?>
<Upela moduleVersion="1.0.0" schemaVersion="1.0.0">
	<OrderCount><?php echo $count->getNumber(); ?></OrderCount>
</Upela>
