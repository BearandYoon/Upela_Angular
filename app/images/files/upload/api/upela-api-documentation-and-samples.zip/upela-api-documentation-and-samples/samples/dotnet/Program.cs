using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace Upela
{
    class Program
    {
        static void Main(string[] args)
        {
            Rate();
            //SelectOffer();
            //Ship();
            //Pickup();
            //CancelPickup();
            //Track();
        }

        static string ExecQuery(string method, string request)
        {
            string url = "https://dev.upela.com/api/"; // test
            //string url = "https://www.upela.com/api/"; // production
            url = url + method + "/";
            var client = new HttpClient();
            var content = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("request", request)
                });
            var result = client.PostAsync(url, content).Result;
            string resultContent = result.Content.ReadAsStringAsync().Result;
            return resultContent;
        }

        static void Rate()
        {
            string request = @"{
              ""account"":{
                  ""login"":""your Upela account login"",
                  ""password"":""your Upela account password""
              },
              ""ship_from"":{
                  ""code_pays"":""FR"",
                  ""code_postal"":""75008"",
                  ""ville"":""Paris"",
                  ""pro"":1
              },
              ""ship_to"":{
                  ""code_pays"":""FR"",
                  ""code_postal"":""31000"",
                  ""ville"":""Toulouse"",
                  ""pro"":0
              },
              ""colis"":[
                  {""nombre"":2, ""poids"":1, ""x"":10, ""y"":10, ""z"":10},
                  {""nombre"":1, ""poids"":1.5, ""x"":10, ""y"":10, ""z"":10}
              ],
              ""date_envoi"":""2016-04-05"",
              ""mesures"":""fr"",
              ""selection"":""cheapest_and_fastest""
            }";
            string result = ExecQuery("rate", request);
            Console.WriteLine(result);
        }

        static void SelectOffer()
        {
            string request = @"{
              ""account"":{
                  ""login"":""your Upela account login"",
                  ""password"":""your Upela account password""
              },
              ""id_expeditions"":1054271,
              ""id_offres"":5834317
            }";
            string result = ExecQuery("select_offer", request);
            Console.WriteLine(result);
        }

        static void Ship()
        {
            string request = @"{
              ""account"":{
                  ""login"":""your Upela account login"",
                  ""password"":""your Upela account password""
              },
              ""id_expeditions"":1054271,
              ""ship_from"":{
                  ""societe"":""My company"",
                  ""nom"":""Prénom Nom"",
                  ""telephone"":""0101010101"",
                  ""email"":""xxxxx@xxxxx.com"",
                  ""ligne1"":""17bis rue la Boétie"",
                  ""ligne2"":""..."",
                  ""code_pays"":""FR"",
                  ""code_postal"":""75008"",
                  ""ville"":""Paris"",
                  ""pro"":1
              },
              ""ship_to"":{
                  ""societe"":""Company XYZ"",
                  ""nom"":""Prénom Nom"",
                  ""telephone"":""0101010101"",
                  ""email"":""xxxxx@xxxxx.com"",
                  ""ligne1"":""..."",
                  ""ligne2"":""..."",
                  ""code_pays"":""FR"",
                  ""code_postal"":""31000"",
                  ""ville"":""Toulouse"",
                  ""pro"":0
              },
              ""raison"":""Commercial"",
              ""contenu"":""Contenu de l'envoi"",
              ""label_format"":""PDF""
            }";
            string result = ExecQuery("ship", request);
            Console.WriteLine(result);
        }

        static void Pickup()
        {
            string request = @"{
              ""account"":{
                  ""login"":""your Upela account login"",
                  ""password"":""your Upela account password""
              },
              ""id_expeditions"":1054271,
              ""ship_from"":{
                        ""societe"":""My company"",
                  ""nom"":""Prénom Nom"",
                  ""telephone"":""0101010101"",
                  ""email"":""xxxxx@xxxxx.com"",
                  ""ligne1"":""17bis rue la Boétie"",
                  ""ligne2"":""..."",
                  ""code_pays"":""FR"",
                  ""code_postal"":""75008"",
                  ""ville"":""Paris"",
                  ""pro"":1
              },
              ""colis"":[
                  {""nombre"":2, ""poids"":1, ""x"":10, ""y"":10, ""z"":10},
                  {""nombre"":1, ""poids"":1.5, ""x"":10, ""y"":10, ""z"":10}
              ],
              ""mesures"":""fr"",
              ""date_envoi"":""2016-04-05"",
              ""ready_time"":""1100"",
              ""close_time"":""1800""
            }";
            string result = ExecQuery("pickup", request);
            Console.WriteLine(result);
        }

        static void CancelPickup()
        {
            string request = @"{
              ""account"":{
                  ""login"":""your Upela account login"",
                  ""password"":""your Upela account password""
              },
              ""id_expeditions"":1054271
            }";
            string result = ExecQuery("cancel_pickup", request);
            Console.WriteLine(result);
        }

        static void Track()
        {
            string request = @"{
              ""account"":{
                  ""login"":""your Upela account login"",
                  ""password"":""your Upela account password""
              },
              ""id_expeditions"":1054271
            }";
            string result = ExecQuery("track", request);
            Console.WriteLine(result);
        }
    }
}
