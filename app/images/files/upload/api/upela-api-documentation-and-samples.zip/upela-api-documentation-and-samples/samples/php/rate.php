<?php

	require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config.php';

	$api = new UpelaApi();

	$api
		->setUrl(UPELA_API_URL)
		->setMethod(UPELA_API_METHOD)
		->setLogin(UPELA_LOGIN) // set here you Upela account login
		->setPassword(UPELA_PASSWORD); // set here you Upela account password
	
  $request = array(
    'ship_from' => array(
      'code_pays' => 'FR',
      'code_postal' => '75008',
      'ville' => 'Paris',
      'pro' => 1,
    ),
    'ship_to' => array(
      'code_pays' => 'FR',
      'code_postal' => '31000',
      'ville' => 'Toulouse',
      'pro' => 1,
    ),
    'colis' => array(
      array('nombre' => 2, 'poids' => 1, 'x' => 10, 'y' => 10, 'z' => 10),    
      array('nombre' => 1, 'poids' => 1.5, 'x' => 10, 'y' => 10, 'z' => 10),    
    ),
    'date_envoi' => '2014-07-22',
    'mesures' => 'fr',
    'selection' => 'cheapest_and_fastest', // possible values : all, cheapest_and_fastest, cheapest, fastest 
  );
  
  $response = $api->rate($request);

  print_r($response);

/*
SAMPLE REPONSE :

Array
(
    [id_clients] => 3071
    [id_commandes] => 115160
    [id_expeditions] => 140915
    [offres] => Array
        (
            [0] => Array
                (
                    [id] => 592942
                    [code_service] => 11
                    [service] => UPS Standard
                    [code_transporteur] => UPS
                    [transporteur] => UPS
                    [date_livraison] => 2014-07-23 23:30
                    [prix_ht] => 30.34
                    [tva] => 20
                    [prix_ttc] => 36.41
                    [code_devises] => eur
                )

        )

    [success] => 1
    [errors] => Array
        (

        )

)
*/

?>