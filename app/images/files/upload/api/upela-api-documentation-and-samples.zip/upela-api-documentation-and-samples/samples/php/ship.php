<?php

	require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config.php';

	$api = new UpelaApi();

	$api
		->setUrl(UPELA_API_URL)
		->setMethod(UPELA_API_METHOD)
		->setLogin(UPELA_LOGIN) // set here you Upela account login
		->setPassword(UPELA_PASSWORD); // set here you Upela account password
	
  $request = array(
    'id_expeditions' => 140915,
    'ship_from' => array(
      'societe' => 'My company',
      'nom' => 'Prénom Nom',
      'telephone' => '0101010101',
      'email' => 'xxxxx@xxxxx.com',
      'ligne1' => '17bis rue la Boétie',
      'ligne2' => '...',
      'code_pays' => 'FR',
      'code_postal' => '75008',
      'ville' => 'Paris',
      'pro' => 1,
    ),
    'ship_to' => array(
      'societe' => 'Company XYZ',
      'nom' => 'Prénom Nom',
      'telephone' => '0101010101',
      'email' => 'xxxxx@xxxxx.com',
      'ligne1' => '...',
      'ligne2' => '...',
      'code_pays' => 'FR',
      'code_postal' => '31000',
      'ville' => 'Toulouse',
      'pro' => 1,
    ),
    'raison' => 'Commercial',
    'contenu' => 'Contenu de l\'envoi',
    'label_format' => 'PDF', // possible values are PDF or ZPL
  );
  
  $response = $api->ship($request);

  print_r($response);
  
/*
SAMPLE REPONSE :

Array
(
    [id_clients] => 3071
    [bordereau] => Array
        (
            [code] => 1409158473
            [url] => http://dev.upela.com/tags/1409158473.PDF
        )

    [tracking] => 1Z0476AR9193266418
    [id_expeditions] => 140915
    [code_transporteur] => UPS
    [transporteur] => UPS
    [success] => 1
    [errors] => Array
        (
        )

)

*/

?>