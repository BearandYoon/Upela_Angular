<?php

/**
 * Upela API connector
 */
class UpelaApi {

# CLASS CONSTANTS

	const METHOD_GET 	= 'get';
	const METHOD_POST 	= 'post';

	const API_URL_TEST = 'https://dev.upela.com/api/';
	const API_URL_PRODUCTION = 'https://www.upela.com/api/';
	
	protected $url = '';

	protected $login = '';

	protected $password = '';

	protected $method = 'post';
	
	protected $timeout = 30;

# PUBLIC METHODS

	# GETTERS / SETTERS

	/**
	 * Gets API url
	 * @return string $url Url
	 */
	public function getUrl() {

		return $this->url;

	} // getUrl

	/**
	 * Sets API url
	 * @param string $url
	 * @return UpelaApi Self
	 */
	public function setUrl($url) {

		$this->url = (string)$url;

		return $this;

	} // setUrl

	/**
	 * Gets API login
	 * @return string Login
	 */
	public function getLogin() {

		return $this->login;

	} // getLogin

	/**
	 * Sets API login
	 * @param string $login New login
	 * @return UpelaApi Self
	 */
	public function setLogin($login) {

		$this->login = (string)$login;

		return $this;

	} // setLogin

	/**
	 * Gets API password
	 * @return string Password
	 */
	public function getPassword() {

		return $this->password;

	} // getPassword

	/**
	 * Sets API password
	 * @param string $password New password
	 * @return UpelaApi Self
	 */
	public function setPassword($password) {

		$this->password = (string)$password;

		return $this;

	} // setPassword

	/**
	 * Gets API method
	 * @return string Method (get or post)
	 */
	public function getMethod() {

		return $this->method;

	} // getMethod

	/**
	 * Sets API method
	 * param string $method Method (get or post)
	 * @return UpelaApi Self
	 */
	public function setMethod($method) {

		if (in_array((string)$method, array(self::METHOD_GET, self::METHOD_POST), true)) {

			$this->method = (string)$method;

		} // if

		return $this;

	} // setMethod

	/**
	 * Gets curl timeout
	 * @return int Number of seconds
	 */
	public function getTimeout() {
	
		return $this->timeout;
	
	} // getTimeout
	
	/**
	 * Sets curl timeout
	 * param int $timeout Number of seconds 
	 * @return UpelaApi Self
	 */
	public function setTimeout($timeout) {
		
		$this->timeout = (int)$timeout;
		
		return $this;
	
	} // setTimeout

	
	
	# REQUESTS
	public function login($data){

		return $this->call('login', $data);

	}

	public function rate($data){

		return $this->call('rate', $data);

	}

	public function selectOffer($data){

		return $this->call('select_offer', $data);

	}

	public function ship($data){

		return $this->call('ship', $data);

	}

	public function pickup($data){

		return $this->call('pickup', $data);


	}

	public function cancelPickup($data){

		return $this->call('cancel_pickup', $data);

	}

	public function track($data){

		return $this->call('track', $data);

	}

	# CALL

	protected function call($method, $data){

		$url = $this->getRequestUrl($method);

		$request_string = $this->getRequestString($data);

		switch ($this->getMethod()) {

			case self::METHOD_GET:

				$request_result = $this->makeGetRequest($url, $request_string);

			break;

			default:
			case self::METHOD_POST:

				$request_result = $this->makePostRequest($url, $request_string);

			break;

		} // switch
		
		if ($request_result){
			
			if (substr($request_result, 0, 1) != '{' && strpos($request_result, '{')!==false) {

				$request_result = substr($request_result, strpos($request_result, '{'));
				
			}

			$result = json_decode($request_result, true);

			if ($result && is_array($result)) {

				return $result;

			} // if

		}// if

		return array();

	}

	protected function initCurlHandle($url, $method){

		$rCurl = curl_init($url);

		curl_setopt($rCurl, CURLOPT_RETURNTRANSFER, 1);

		curl_setopt($rCurl, CURLOPT_TIMEOUT, (int)$this->getTimeout());

    curl_setopt($rCurl, CURLOPT_SSL_VERIFYPEER, 0);
    
    curl_setopt($rCurl, CURLOPT_SSL_VERIFYHOST, 0);
		
		switch ($method) {

			case self::METHOD_GET:

				curl_setopt($rCurl, CURLOPT_HTTPGET, 1);

			break;

			case self::METHOD_POST:

				curl_setopt($rCurl, CURLOPT_POST, 1);

			break;

		} // switch

		return $rCurl;

	}

	protected function makeGetRequest($url, $request_string){
		$call_url = $url . '?' . http_build_query(array('request' => $request_string));
		$curl = $this->initCurlHandle($call_url, self::METHOD_GET);
		return curl_exec($curl);
	}

	protected function makePostRequest($url, $request_string){
    $call_url = $url;
		$curl = $this->initCurlHandle($call_url, self::METHOD_POST);
		curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query(array('request' => $request_string)));
		return curl_exec($curl);
	}

	protected function getRequestUrl($method){
		
		return rtrim($this->getUrl(), '/') . '/' . strtolower($method) . '/';

	}

	protected function getRequestString(array $data){

		return json_encode(array('account' => $this->getCredentials()) + $data);

	}

	/**
	 * Gets credentials
	 * @return array
	 */
	protected function getCredentials(){

		return array('login' => $this->getLogin(), 'password' => $this->getPassword());

	}


}