<?php

	require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config.php';

	$api = new UpelaApi();

	$api
		->setUrl(UPELA_API_URL)
		->setMethod(UPELA_API_METHOD)
		->setLogin(UPELA_LOGIN) // set here you Upela account login
		->setPassword(UPELA_PASSWORD); // set here you Upela account password
	
  $request = array(
    'id_expeditions' => 140915,
    'ship_from' => array(
      'societe' => 'My company',
      'nom' => 'Prénom Nom',
      'telephone' => '0101010101',
      'email' => 'xxxxx@xxxxx.com',
      'ligne1' => '17bis rue la Boétie',
      'ligne2' => '...',
      'code_pays' => 'FR',
      'code_postal' => '75008',
      'ville' => 'Paris',
      'pro' => 1,
    ),
    'colis' => array(
      array('nombre' => 2, 'poids' => 1, 'x' => 10, 'y' => 10, 'z' => 10),    
      array('nombre' => 1, 'poids' => 1.5, 'x' => 10, 'y' => 10, 'z' => 10),    
    ),
    'mesures' => 'fr',
    'date_envoi' => '2014-07-22',
    'ready_time' => '1100',
    'close_time' => '1800',
  );
  
  $response = $api->pickup($request);

  print_r($response);

/*
SAMPLE REPONSE :

Array
(
    [id_clients] => 3071
    [id_expeditions] => 140915
    [id_pickups] => 15661
    [reservation_number] => 2929602E9CP
    [code_transporteur] => UPS
    [transporteur] => UPS
    [success] => 1
    [errors] => Array
        (
        )

)

*/

?>