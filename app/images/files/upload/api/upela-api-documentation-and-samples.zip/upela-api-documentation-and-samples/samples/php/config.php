<?php

	require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'UpelaApi.php';

  define('UPELA_API_URL', UpelaApi::API_URL_TEST);
  define('UPELA_API_METHOD', UpelaApi::METHOD_POST);
  define('UPELA_LOGIN', 'xxxxx@xxx.xxx'); // set here you Upela account login
  define('UPELA_PASSWORD', 'xxxxxxxx'); // set here you Upela account password

?>