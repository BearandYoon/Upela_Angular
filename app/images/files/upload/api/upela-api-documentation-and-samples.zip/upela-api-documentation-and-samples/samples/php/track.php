<?php

	require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config.php';

	$api = new UpelaApi();

	$api
		->setUrl(UPELA_API_URL)
		->setMethod(UPELA_API_METHOD)
		->setLogin(UPELA_LOGIN) // set here you Upela account login
		->setPassword(UPELA_PASSWORD); // set here you Upela account password
	
  $request = array(
    'id_expeditions' => 140577,
  );
  
  $response = $api->track($request);

  print_r($response);
  

/*
SAMPLE REPONSE :

Array
(
    [id_clients] => 3071
    [infos] => Array
        (
            [result] => ok
            [track] => Array
                (
                    [0] => Array
                        (
                            [date] => 21/07/2014 20:23:16
                            [date_unformatted] => 2014-07-21 20:23:16
                            [lieu] => Array
                                (
                                    [cp] =>
                                    [ville] => LYON - FRANCE
                                    [pays] =>
                                )

                            [desc] => Processed at LYON - FRANCE
                            [code] => PL
                        )

                    [1] => Array
                        (
                            [date] => 21/07/2014 20:15:47
                            [date_unformatted] => 2014-07-21 20:15:47
                            [lieu] => Array
                                (
                                    [cp] =>
                                    [ville] => LYON - FRANCE
                                    [pays] =>
                                )

                            [desc] => Arrived at Sort Facility LYON - FRANCE
                            [code] => AF
                        )

                    [2] => Array
                        (
                            [date] => 21/07/2014 19:29:41
                            [date_unformatted] => 2014-07-21 19:29:41
                            [lieu] => Array
                                (
                                    [cp] =>
                                    [ville] => LYON - FRANCE
                                    [pays] =>
                                )

                            [desc] => Departed Facility in LYON - FRANCE
                            [code] => DF
                        )

                )

        )

    [id_expeditions] => 140577
    [success] => 1
    [errors] => Array
        (
        )

)

*/

?>