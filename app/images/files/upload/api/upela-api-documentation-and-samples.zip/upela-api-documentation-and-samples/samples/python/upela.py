#!/usr/bin/env python
# -*- coding: utf-8 -*- 
import json
import requests

def exec_request(method, request):
  url = 'https://dev.upela.com/api/' ## test url
  #url = 'https://www.upela.com/api/' ## production url
  url = url + method + "/"
  request["account"] = {
    "login":"your Upela account login",
    "password":"your Upela account password"
  }
  r = requests.post(url, data={'request': json.dumps(request)})
  #print r.status_code
  #print r.text
  return r.json()

def rate():
  request = {
      "ship_from":{
          "code_pays":"FR",
          "code_postal":"75008",
          "ville":"Paris",
          "pro":1
      },
      "ship_to":{
          "code_pays":"FR",
          "code_postal":"31000",
          "ville":"Toulouse",
          "pro":0
      },
      "colis":[
          {"nombre":2, "poids":1, "x":10, "y":10, "z":10},
          {"nombre":1, "poids":1.5, "x":10, "y":10, "z":10}
      ],
      "date_envoi":"2016-04-05",
      "mesures":"fr",
      "selection":"cheapest_and_fastest"
  }
  print exec_request("rate", request)

def select_offer():
  request = {
      "id_expeditions":1054264,
      "id_offres":5834305
  }
  print exec_request("select_offer", request)

def ship():
  request = {
      "id_expeditions":1054264,
      "ship_from":{
          "societe":"My company",
          "nom":"Prénom Nom",
          "telephone":"0101010101",
          "email":"xxxxx@xxxxx.com",
          "ligne1":"17bis rue la Boétie",
          "ligne2":"...",
          "code_pays":"FR",
          "code_postal":"75008",
          "ville":"Paris",
          "pro":1
      },
      "ship_to":{
          "societe":"Company XYZ",
          "nom":"Prénom Nom",
          "telephone":"0101010101",
          "email":"xxxxx@xxxxx.com",
          "ligne1":"...",
          "ligne2":"...",
          "code_pays":"FR",
          "code_postal":"31000",
          "ville":"Toulouse",
          "pro":0
      },
      "raison":"Commercial",
      "contenu":"Contenu de l'envoi",
      "label_format":"PDF" # possible values are PDF or ZPL
  }
  print exec_request("ship", request)

def pickup():
  request = {
      "id_expeditions":1054264,
      "ship_from":{
          "societe":"My company",
          "nom":"Prénom Nom",
          "telephone":"0101010101",
          "email":"xxxxx@xxxxx.com",
          "ligne1":"17bis rue la Boétie",
          "ligne2":"...",
          "code_pays":"FR",
          "code_postal":"75008",
          "ville":"Paris",
          "pro":1
      },
      "colis":[
          {"nombre":2, "poids":1, "x":10, "y":10, "z":10},
          {"nombre":1, "poids":1.5, "x":10, "y":10, "z":10}
      ],
      "mesures":"fr",
      "date_envoi":"2016-04-05",
      "ready_time":"1100",
      "close_time":"1800"
  }
  print exec_request("pickup", request)

def cancel_pickup():
  request = {
      "id_expeditions":1054264
  }
  print exec_request("cancel_pickup", request)

def track():
  request = {
      "id_expeditions":1054264
  }
  print exec_request("track", request)

rate()
#select_offer()
#ship()
#pickup()
#cancel_pickup()
#track()

