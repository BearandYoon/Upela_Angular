<?php 

/*
 * Upela connector - shipping module
 * More info on www.upela.com
 * @copyright Upela <https://www.upela.com>
 * @author Benjamin Abbou <benjamin.abbou@hexalogic.fr>
 * @version 1.0.0
 */

define('REQUIRE_SECURE', FALSE);
$moduleVersion = '1.0.0';
$schemaVersion = '1.0.0';

//require '../../config/config.inc.php';
// put file in modules directory
include(dirname(__FILE__).'/../config/config.inc.php');

// Timezone from PrestaShop
$psTimeZone = new DateTimeZone(Configuration::get('PS_TIMEZONE'));

header('Content-Type: text/xml;charset=utf-8');
header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');

// HTTP/1.1
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', false);

// HTTP/1.0
header('Pragma: no-cache');     

function isPrestashop14x() {
  return version_compare(_PS_VERSION_, '1.5.0', 'lt');
}

// write xml document declaration
function writeXmlDeclaration() {
	echo '<?xml version="1.0" standalone="yes" ?>';
}

function writeStartTag($tag, $attributes = null) {
	echo '<' . $tag;
	if ($attributes != null) {
		echo ' ';
		foreach ($attributes as $name => $attribValue) {
			echo $name . '="' . htmlspecialchars($attribValue). '" ';	
		}
	}
	echo '>';
}

// write closing xml tag
function writeCloseTag($tag) {
	echo '</' . $tag . '>';
}

// Output the given tag\value pair
function writeElement($tag, $value) {
	writeStartTag($tag);
	echo htmlspecialchars($value);
	writeCloseTag($tag);
}

// Outputs the given name/value pair as an xml tag with attributes
function writeFullElement($tag, $value, $attributes) {
	echo '<' . $tag . ' ';

	foreach ($attributes as $name => $attribValue) {
		echo $name . '="' . htmlspecialchars($attribValue) . '" ';	
	}
	echo '>';
	echo htmlspecialchars($value);
	writeCloseTag($tag);
}

// Function used to output an error and quit.
function outputError($code, $error) {       
	writeStartTag('Error');
	writeElement('Code', $code);
	writeElement('Description', $error);
	writeCloseTag('Error');
}       

$secure = false;
try {
	if (isset($_SERVER['HTTPS']))
	{
		$secure = ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == '1');
	}
} catch(Exception $e) {
}

// Open the XML output and root
writeXmlDeclaration();
writeStartTag('Upela', array('moduleVersion' => $moduleVersion, 'schemaVersion' => $schemaVersion));

// Enforse SSL
if (!$secure && REQUIRE_SECURE) {
	outputError(10, 'A secure (https://) connection is required.');
} else {
	if (checkAdminLogin()) {
		$action = (isset($_REQUEST['action']) ? $_REQUEST['action'] : '');
		switch (strtolower($action)) {
			case 'getmodule': getModule(); break;
			case 'getstore': getStore(); break;
			case 'getcount': getCount(); break;
			case 'getorders': getOrders(); break;
			case 'getstatuscodes': getStatusCodes(); break;
			case 'updatestatus': updateStatus(); break;
			case 'updateshipment': updateShipment(); break;
			case 'updateorder': updateOrder(); break;
			default:
				outputError(20, "'$action' is not supported.");
		}
	}
}

// Close the output
writeCloseTag('Upela');

//Check username, password
function checkAdminLogin() {
	$loginOK = false;

	if (isset($_REQUEST['username']) && isset($_REQUEST['password'])) {

		$username = $_REQUEST['username'];
		$password = $_REQUEST['password'];
		/*
		$sql = new DbQuery();
		$sql->select('id_employee');
		$sql->from('employee', 'e');
		$sql->where("e.email = '$username'");
    */
    $sql = "select id_employee from `" . _DB_PREFIX_ . "employee` where email = '$username'";
		$employeeId = Db::getInstance()->getRow($sql);
		
		if ($employeeId) {
			$employeeId = $employeeId['id_employee'];

			$encryptedPassword = Tools::encrypt($password);
			if (Employee::checkPassword($employeeId, $encryptedPassword)) {
				$loginOK = true;        
			}
		}
	}

	if (!$loginOK) {
		outputError(50, 'The username or password is incorrect or user provided does not have administrator access.');
	}

	return $loginOK;
}

// Get module data
function getModule() {
	writeStartTag('Module');

	writeElement('Platform', 'PrestaShop');
	writeElement('Developer', 'Upela (contact@upela.com)');

	writeStartTag('Capabilities');
	writeElement('DownloadStrategy', 'ByModifiedTime');
	writeFullElement('OnlineCustomerID', '', array('supported' => 'true', 'dataType' => 'numeric'));
	writeFullElement('OnlineStatus', '', array('supported' => 'true', 'supportsComments' => 'false', 'downloadOnly'=>'false', 'dataType' => 'numeric'));
	writeFullElement('OnlineShipmentUpdate', '', array('supported' => 'true'));
	writeCloseTag('Capabilities');
	writeStartTag('Communications');
	//writeFullElement('Http', '', array('expect100Continue' => 'true'));
	writeElement('ResponseEncoding', 'UTF-8');
	writeCloseTag('Communications');

	writeCloseTag('Module');
}

// Write store data
function getStore() {

	$name = Configuration::get('PS_SHOP_NAME');
	$companyOrOwner = Configuration::get('');
	$email = Configuration::get('PS_SHOP_EMAIL');
	$street1 = Configuration::get('PS_SHOP_ADDR1');
	$street2 = Configuration::get('PS_SHOP_ADDR2');
	$street3 = '';
	$city = Configuration::get('PS_SHOP_CITY');

	$state = Configuration::get('PS_SHOP_STATE');
	$stateId = Configuration::get('PS_SHOP_STATE_ID');

  if ($stateId > 0) {
    /*
  	$sql = new DbQuery();
  	$sql->select('iso_code');
  	$sql->from('state', 's');
  	$sql->where("s.id_state = $stateId");
    */
    $sql = "select iso_code from `" . _DB_PREFIX_ . "state` where id_state = $stateId";
  	$stateRow = Db::getInstance()->getRow($sql);
  	$stateCode = !empty($stateRow) && isset($stateRow['iso_code']) ? $stateRow['iso_code'] : null;
  } else {
    $stateCode = null;
  }
  
	$postalCode = Configuration::get('PS_SHOP_CODE');
	$country = Configuration::get('PS_SHOP_COUNTRY');
	$countryId = Configuration::get('PS_SHOP_COUNTRY_ID');

  if ($countryId > 0) {
  	/*
    $sql = new DbQuery();
  	$sql->select('iso_code');
  	$sql->from('country', 'c');
  	$sql->where("c.id_country = $countryId");
    */
    $sql = "select iso_code from `" . _DB_PREFIX_ . "country` where id_country = $countryId";
  	$countryRow = Db::getInstance()->getRow($sql);
  	$countryCode = !empty($countryRow) && isset($countryRow['iso_code']) ? $countryRow['iso_code'] : null;
  } else {
    $countryCode = null;
  }

  $phone = Configuration::get('PS_SHOP_PHONE');
	$website = '';
  
  /*
	$status = new OrderState();
	$shippingStatus = $status->getOrderStates('1');
  */

	writeStartTag('Store');
	writeElement('Platform', 'prestashop');
	writeElement('Name', $name);
	writeElement('CompanyOrOwner', $companyOrOwner);
	writeElement('Email', $email);
	writeElement('Street1', $street1);
	writeElement('Street2', $street2);
	writeElement('Street3', $street3);
	writeElement('City', $city);
	writeElement('State', $state);
	writeElement('StateCode', $stateCode);
	writeElement('PostalCode', $postalCode);
	writeElement('Country', $country);
	writeElement('CountryCode', $countryCode);
	writeElement('Phone', $phone);
	writeElement('Website', $website);
	writeCloseTag('Store');
  
  /*
	writeStartTag('StatusCodes');
	foreach ($shippingStatus as $status) {
		writeStartTag('StatusCode');
		writeElement('Code', $status['id_order_state']);
		writeElement('Name', $status['name']);
		writeCloseTag('StatusCode');
	}
	writeCloseTag('StatusCodes');
  */
}

// Get the count of orders greater than the start date
function getCount() {
	global $psTimeZone;
	$start = '1970-01-01';
	
	if($_REQUEST['start']) {
		$start = $_REQUEST['start'];
	}
	
	//Date/Time in UTC
	//$start = new DateTime($start, new DateTimeZone('UTC'));
	//$start = $start->setTimezone($psTimeZone);
	
	// only get orders through 2 seconds ago
	//$end = new DateTime(date('Y-m-d\TH:i:s', time()-2), $psTimeZone);
  $end = date('Y-m-d H:i:s', time() - 2);
  
  $start = toLocalSqlDate($start);

	// Write the params for easier diagnostics
	writeStartTag('Parameters');
	writeElement('Start', FormatDate($start));
	writeElement('End', FormatDate($end));
	writeCloseTag('Parameters');

	//$startSQL = $start->format('Y-m-d H:i:s');
	//$endSQL = $end->format('Y-m-d H:i:s');
	/*
	$sql = new DbQuery();
	$sql->select('count(*) as count');
	$sql->from('orders', 'o');
	$sql->where("o.date_upd > '$start'");
	$sql->where("o.date_upd < '$end'");
  */
  $sql = "select count(*) as count from `" . _DB_PREFIX_ . "orders` where date_upd > '$start' and date_upd < '$end'";

	$count = Db::getInstance()->getRow($sql);

	writeElement('OrderCount', $count['count']);
}

// Get all orders greater than the given start date, limited by max count
function getOrders() {
	$start = '1970-01-01';
	$maxcount = 100;
	global $psTimeZone;

	if (isset($_REQUEST['start'])) {
		$start = $_REQUEST['start'];
	}

	if (isset($_REQUEST['maxcount'])) {
		$maxcount = (int)$_REQUEST['maxcount'];
	}
	
	//Date/Time in UTC
	//$start = new DateTime($start, new DateTimeZone('UTC'));
	//$start = $start->setTimezone($psTimeZone);
	
	// only get orders through 2 seconds ago
	//$end = new DateTime(date('Y-m-d\TH:i:s', time()-2), $psTimeZone);
  $end = date('Y-m-d H:i:s', time() - 2);
  
  $start = toLocalSqlDate($start);

	// Write the params for easier diagnostics
	writeStartTag('Parameters');
	writeElement('Start', FormatDate($start));
	writeElement('End', FormatDate($end));
	writeElement('MaxCount', $maxcount);
	writeCloseTag('Parameters');                                    

	//$startSQL = $start->format('Y-m-d H:i:s');
	//$endSQL = $end->format('Y-m-d H:i:s');
	/*
	$sql = new DbQuery();
	$sql->select('id_order');
	$sql->from('orders', 'o');
	$sql->where("o.date_upd > '$start'");
	$sql->where("o.date_upd < '$end'");
	$sql->orderBy('o.date_upd');
	$sql->limit($maxcount,0);
  */
  $maxcount = intval($maxcount);
  $sql = "select id_order from `" . _DB_PREFIX_ . "orders` where date_upd > '$start' and date_upd < '$end' order by date_upd limit $maxcount";
	
	$orderids = Db::getInstance()->executeS($sql);
	
	writeStartTag('Orders');

	$start = null;
	$processedIds = '';
	
	foreach ($orderids as $orderid) {
		$order = new Order($orderid['id_order']);
		//$start = new DateTime($order->date_upd, $psTimeZone);
		//$startSQL = $start->format('Y-m-d H:i:s');
    $startSQL = date('Y-m-d H:i:s', strtotime($order->date_upd));
		
		// Add the id to the list we have processed
		if ($processedIds != '') {
			$processedIds .= ', ';
		}
		
		$processedIds .= $orderid['id_order'];
		WriteOrder($order);
	}

	//make sure that we dont skip an order if it has the same lastmodified as order #50 from above
	if ($processedIds) {
		/*
    $sql = new DbQuery();
		$sql->select('id_order');
		$sql->from('orders', 'o');
		$sql->where("o.date_upd = '$startSQL'");
		$sql->where("o.id_order not in ($processedIds)");
    */		
    $sql = "select id_order from `" . _DB_PREFIX_ . "orders` where date_upd = '$startSQL' and id_order not in ($processedIds)";
		$skippedOrderids = Db::getInstance()->executeS($sql);
		
		foreach ($skippedOrderids as $orderid) {
			$order = new Order($orderid['id_order']);
			WriteOrder($order);
		}
	}

	writeCloseTag('Orders');
}

// Output the order as xml
function WriteOrder($order) {                 
	global $secure;
	global $psTimeZone;
	
	//$orderDate = new DateTime($order->date_add, $psTimeZone);
	//$orderDate = $orderDate->setTimezone(new DateTimeZone('UTC'));
	
	//$lastModified = new DateTime($order->date_upd, $psTimeZone);
	//$lastModified = $lastModified->setTimezone(new DateTimeZone('UTC'));
	
	writeStartTag('Order');

	writeElement('OrderNumber', $order->id);
	//writeElement('OrderDate', $orderDate->format('Y-m-d\TH:i:s'));
	//writeElement('LastModified', $lastModified->format('Y-m-d\TH:i:s'));
  writeElement('OrderDate', FormatDate($order->date_add));
  writeElement('LastModified', FormatDate($order->date_upd));
	
	$carrier = new Carrier($order->id_carrier);
	
	writeElement('ShippingMethod', $carrier->name);
	writeElement('StatusCode', $order->current_state);
  writeElement('CustomerID', $order->id_customer);

	writeStartTag('Notes');
	
  /*
	$sql = new DbQuery();
	$sql->select('id_message');
	$sql->from('message', 'm');
	$sql->where("m.id_order = '$order->id'");
  */
  $sql = "select id_message from `" . _DB_PREFIX_ . "message` where id_order = '$order->id'";
	
	$messageIds = Db::getInstance()->executeS($sql);
	
	foreach($messageIds as $messageId) {
		$message = new Message($messageId['id_message']);
		writeFullElement('Note', $message->message, array('public' => 'true'));
	}
	
	writeCloseTag('Notes');
	
	$customer = new Customer($order->id_customer);
	$billToAddress = new Address($order->id_address_invoice);
	$billToState = new State($billToAddress->id_state);
	$billToCountry = new Country($billToAddress->id_country);
	
	writeStartTag('BillingAddress');
	writeElement('FirstName', $billToAddress->firstname);
	writeElement('LastName', $billToAddress->lastname);
	writeElement('Company',$billToAddress->company);
	writeElement('Street1', $billToAddress->address1);
	writeElement('Street2',$billToAddress->address2);
	writeElement('Street3','');
	writeElement('City', $billToAddress->city);
	writeElement('State', $billToState->iso_code);
	writeElement('PostalCode', $billToAddress->postcode);
	writeElement('Country', $billToAddress->country);
	writeElement('CountryCode', $billToCountry->iso_code);
	writeElement('Phone', $billToAddress->phone);
	writeElement('Email',$customer->email);
	writeCloseTag('BillingAddress');
	
	
	$shipToAddress = new Address($order->id_address_delivery);
	$shipToState = new State($shipToAddress->id_state);
  $shipToCountry = new Country($shipToAddress->id_country);
	
	writeStartTag('ShippingAddress');
	writeElement('FirstName', $shipToAddress->firstname);
	writeElement('LastName', $shipToAddress->lastname);
	writeElement('Company',$shipToAddress->company);
	writeElement('Street1', $shipToAddress->address1);
	writeElement('Street2',$shipToAddress->address2);
	writeElement('Street3','');
	writeElement('City', $shipToAddress->city);
	writeElement('State', $shipToState->iso_code);
	writeElement('PostalCode', $shipToAddress->postcode);
	writeElement('Country', $shipToAddress->country);
  writeElement('CountryCode', $shipToCountry->iso_code);
	writeElement('Phone', $shipToAddress->phone);
	writeElement('Email',$customer->email);
	writeCloseTag('ShippingAddress');
	
	writeStartTag('Payment');
	writeElement('Method', $order->payment);
	writeCloseTag('Payment');

	WriteOrderItems($order->getProducts());

	WriteOrderTotals($order);

	writeCloseTag('Order');
}

// Outputs notes elements
function WriteNote($noteText, $public) {
	$attributes = array('public' => $public ? 'true' : 'false');

	writeFullElement('Note', $noteText, $attributes);
}

// writes a single order total
function WriteOrderTotal($name, $value, $class, $impact = 'add') {
	if ($value > 0) {
		writeFullElement('Total', $value, array('name' => $name, 'class' => $class, 'impact' => $impact));
	}
}

// Write all totals lines for the order
function WriteOrderTotals($order) {
	writeStartTag('Totals');
  
	//WriteOrderTotal('Shipping and Handling', $order->total_shipping_tax_incl, 'shipping', 'add');
	//WriteOrderTotal('Discounts', $order->total_discounts, 'discount','subtract');
	//WriteOrderTotal('Grand Total', $order->total_paid, 'total', 'none');
  writeElement('Shipping', $order->total_shipping_tax_incl);
  writeElement('Discounts', $order->total_discounts);
  writeElement('GrandTotal', $order->total_paid);
  
	writeCloseTag('Totals');
}

// Write XML for all products for the given order
function WriteOrderItems($orderItems) {
	writeStartTag('Items');

	foreach ($orderItems as $item) {
		writeStartTag('Item');

		writeElement('Code', $item['product_reference']);
		writeElement('SKU', $item['product_reference']);
		writeElement('Name', $item['product_name']);
		writeElement('Quantity', (int)$item['product_quantity']);
		//writeElement('UnitPrice', $item['product_price']);
		writeElement('UnitPrice', $item['unit_price_tax_incl']);
		writeElement('Weight', $item['product_weight']);

		writeCloseTag('Item');
	}

	writeCloseTag('Items');
}

// Returns the shipping status codes for the store
function getStatusCodes() {
	$status = new OrderState();
	$shippingStatus = $status->getOrderStates('1');

	writeStartTag('StatusCodes');
	foreach ($shippingStatus as $status) {
		writeStartTag('StatusCode');
		writeElement('Code', $status['id_order_state']);
		writeElement('Name', $status['name']);
		writeCloseTag('StatusCode');
	}
	writeCloseTag('StatusCodes');
	
}

// Update order status
function updateStatus() {
	$orderId = 0;
	$statusCode = '';
	$comments = '';

	if (!isset($_REQUEST['order']) || !isset($_REQUEST['status']) || !isset($_REQUEST['comments'])) {
		outputError(50, 'Not all parameters supplied.');
		return;
	}

	$orderId = $_REQUEST['order'];
	$statusCode = (int)$_REQUEST['status'];
	$comments = $_REQUEST['comments'];

	// write the params for easier diagnostics
	writeStartTag('Parameters');
	writeElement('Order', $orderId);	
	writeElement('Status', $statusCode);
	writeElement('Comments', $comments);
	writeCloseTag('Parameters');
	
	$order = new Order($orderId);
	$order->setCurrentState($statusCode);
	echo '<UpdateSuccess/>';	
}

// Upload tracking
function updateShipment() {
	$orderId = 0;
	$trackingNumber = '';

	if (!isset($_REQUEST['order']) || !isset($_REQUEST['tracking'])) {
		outputError(50, 'Not all parameters supplied.');
		return;
	}

	$orderId = $_REQUEST['order'];
	$trackingNumber = $_REQUEST['tracking'];
	
	// write the params for easier diagnostics
	writeStartTag('Parameters');
	writeElement('OrderID', $orderId);	
	writeElement('Tracking', $trackingNumber);
	writeCloseTag('Parameters');

	$order = new Order($orderId);

	$order->shipping_number = $trackingNumber;
	$order->update();
	
	$orderCarrier = new OrderCarrier($orderId);
	$orderCarrier->tracking_number = $trackingNumber;
	$orderCarrier->update();
	
	echo '<UpdateSuccess/>';	
}

// Upload tracking
function updateOrder() {
	$orderId = 0;
  $statusCode = '';
  $comments = '';
	$trackingNumber = '';

	if (!isset($_REQUEST['order']) || !isset($_REQUEST['status']) || !isset($_REQUEST['tracking'])) {
		outputError(50, 'Not all parameters supplied.');
		return;
	}

	$orderId = $_REQUEST['order'];
  $statusCode = (int)$_REQUEST['status'];
  //$comments = isset($_REQUEST['comments']) ? $_REQUEST['comments'] : null;
	$trackingNumber = $_REQUEST['tracking'];
	
	// write the params for easier diagnostics
	writeStartTag('Parameters');
	writeElement('OrderID', $orderId);
  writeElement('Status', $statusCode);
  //writeElement('Comments', $comments);
	writeElement('Tracking', $trackingNumber);
	writeCloseTag('Parameters');

	$order = new Order($orderId);

  $order->setCurrentState($statusCode);
  
	$order->shipping_number = $trackingNumber;
	$order->update();
	
  if (!isPrestashop14x()) {
  	$orderCarrier = new OrderCarrier((int)$order->getIdOrderCarrier());
    $orderCarrier->id_order = $orderId;
  	$orderCarrier->tracking_number = $trackingNumber;
  	$orderCarrier->update();
  }
	
	echo '<UpdateSuccess/>';	
}

// Converts an xml datetime string to sql date time
function toLocalSqlDate($sqlUtc) {
  $pattern = "/^(\d{4})-(\d{2})-(\d{2})\T(\d{2}):(\d{2}):(\d{2})$/i";

  if (preg_match($pattern, $sqlUtc, $dt)) {
    $unixUtc = gmmktime($dt[4], $dt[5], $dt[6], $dt[2], $dt[3], $dt[1]);  
    return date("Y-m-d H:i:s", $unixUtc);
  }

  return $sqlUtc;
}

// Converts a sql data string to xml date format
function FormatDate($dateSql) {
  $pattern = '/^(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2})$/i';

  if (preg_match($pattern, $dateSql, $dt)) {
    $dateUnix = mktime($dt[4], $dt[5], $dt[6], $dt[2], $dt[3], $dt[1]);
    return gmdate('Y-m-d\TH:i:s', $dateUnix);
  }

  return $dateSql;
}

?>